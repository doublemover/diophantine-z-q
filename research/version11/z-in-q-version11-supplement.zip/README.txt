Version 11 scoped Kato repair and protocol research supplement.
Run python -B restore.py restored, then python -B restored/scripts/check_audit_history.py --self-test.
No conversational transcript. The primary source PDFs are referenced, not redistributed.
