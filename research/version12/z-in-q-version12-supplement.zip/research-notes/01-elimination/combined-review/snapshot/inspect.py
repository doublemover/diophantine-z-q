import json
from pathlib import Path
r=Path('work/quartic-optimization-20261107')
b=json.loads((r/'01-elimination/baseline523.json').read_text()); n=json.loads((r/'03-depth/beta12/final/candidate-ir.json').read_text())
for d in [b,n]:
 print('SYSTEM',len(d['coordinates']))
 for c in d['coordinates']:
  if c['name'].startswith(('detector0.','anchor.','Sscalar.','scalar.')):print(c['id'],c['name'])
 print('FIELDS',list(d))
