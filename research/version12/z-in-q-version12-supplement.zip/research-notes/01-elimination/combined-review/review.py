"""Independent finite audit of the frozen 505-coordinate composition."""
from pathlib import Path
from fractions import Fraction as F
from math import gcd,lcm
from functools import reduce
import json,hashlib,subprocess,sys,copy
H=Path(__file__).resolve().parent
W=H.parents[1]
R=W.parent/'quartic-version6-release/repository'
S=H/'snapshot'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def poly(ts):
 d={}
 for t in ts:
  m=(t.get('sPower',0),tuple(t['monomial']))
  assert tuple(sorted(m[1]))==m[1]
  d[m]=d.get(m,F(0))+F(t['coefficient'])
 return {k:v for k,v in d.items() if v}
def normalized(p):
 d=reduce(lcm,(v.denominator for v in p.values()),1)
 g=reduce(gcd,(abs(int(v*d)) for v in p.values()),0)
 return {k:v*d/g for k,v in p.items()}
def mapped(p,mp):
 q={}
 for (s,m),v in p.items():
  k=s,tuple(sorted(mp[x] for x in m));q[k]=q.get(k,F(0))+v
 return {k:v for k,v in q.items() if v}
def tables(d):
 cs={c['id']:c for c in d['coordinates']};ns={c['name']:c for c in d['coordinates']}
 rs={r['id']:r for r in d['residuals']};rn={r['name']:r for r in d['residuals']}
 assert len(cs)==len(ns)==len(d['coordinates'])
 assert len(rs)==len(rn)==len(d['residuals'])
 used={v for r in rs.values() for s,m in poly(r['terms']) for v in m}
 assert used==set(cs)
 assert ns['input']['id']==0 and cs[0]['protected']
 return cs,ns,rs,rn

pins=[]
for item in read(S/'SOURCES.json'):
 p=Path(item['path']);assert sha(p)==item['sha256'],str(p)
 pins.append(item)
cert=read(S/'certificate505.json')
assert sha(S/'candidate505-ir.json')=='bd9aca7a4a31476e426660d1a33de33552f2a5019bec06104b45938d59f4b966'
assert sha(Path(cert['baseline']))==cert['baselineSha256']=='48a8b8f9263a97d3a1c59f3f0f3553eae628b7aba342d44003e8da840ae84928'
assert sha(Path(cert['depthSource']))==cert['depthSha256']
b=read(Path(cert['baseline']));d=read(Path(cert['depthSource']));n=read(S/'candidate505-ir.json')
bc,bn,br,brn=tables(b);dc,dn,dr,drn=tables(d);nc,nn,nr,nrn=tables(n)
baseline_map={x:dn[c['name']]['id'] for x,c in bc.items() if c['name'] in dn}
expected={name:poly(r['terms']) for name,r in drn.items()}
expected_names={x:c['name'] for x,c in dc.items()}
audit=[]
for operation in cert['operations']:
 path=Path(operation['source']);assert sha(path)==operation['sha256']
 patch=read(path);pc,pn,pr,prn=tables(patch)
 local=dict(baseline_map)
 addedids=set(pc)-set(bc)
 for x in addedids:local[x]=nn[pc[x]['name']]['id']
 assert {int(k):v for k,v in operation['coordinateMap'].items()}==local
 deleted=set(br)-set(pr)
 added=set(pr)-set(br)
 changed={x for x in set(br)&set(pr) if normalized(poly(br[x]['terms']))!=normalized(poly(pr[x]['terms']))}
 removed=set(bc)-set(pc)
 assert set(operation['removedCoordinates'])=={local[x] for x in removed}
 assert set(operation['deletedRows'])=={br[x]['name'] for x in deleted}
 assert {z['sourceRow'] for z in operation['changedRows']}==changed
 for z in operation['changedRows']:
  assert z['name']==br[z['sourceRow']]['name']
  assert z['targetRow']==drn[z['name']]['id']
 for x in deleted|changed:
  name=br[x]['name']
  assert normalized(expected[name])==normalized(mapped(poly(br[x]['terms']),local)),name
  if x in deleted:del expected[name]
  else:expected[name]=mapped(poly(pr[x]['terms']),local)
 for x in added:
  name=pr[x]['name'];assert name not in expected
  expected[name]=mapped(poly(pr[x]['terms']),local)
 for x in removed:del expected_names[local[x]]
 for x in addedids:
  assert local[x] not in expected_names
  expected_names[local[x]]=pc[x]['name']
 renamed=[]
 for x in set(pc)&set(bc):
  if pc[x]['name']!=bc[x]['name']:
   renamed.append([x,bc[x]['name'],pc[x]['name']])
   expected_names[local[x]]=pc[x]['name']
 audit.append({'source':str(path),'sourceSha256':sha(path),'deletedCoordinates':sorted(removed),
               'deletedRows':sorted(deleted),'changedRows':sorted(changed),'addedRows':sorted(added),'renamedCoordinates':renamed})
assert expected=={name:poly(r['terms']) for name,r in nrn.items()}
assert expected_names=={x:c['name'] for x,c in nc.items()}
assert {name for name,q in {r['name']:poly(r['terms']) for r in d['residuals']}.items() if any(s for s,m in q)}=={'anchor.translatedEquation'}
assert {name for name,q in expected.items() if any(s for s,m in q)}=={'anchor.translatedEquation'}
assert n['fixedParameter']=={'name':'C','value':'3^(2^25)','coordinate':False}

# Freeze the exact finite-input source change independently of experiment.py.
src=R/'quartics/quartic-523-540/source-reproduction'
original=(src/'builders/odd-product-asymmetric-source.cjs').read_text()
edits=[("value:'3^(2^27)'","value:'3^(2^26)'"),
 ("LV=PV.map((p,i)=>log('logV'+i,p,40))","LV=PV.map((p,i)=>log('logV'+i,p,i===1?12:40))"),
 ("tests.push({value:fsub(L[i],LP[i]),order:40})","tests.push({value:fsub(L[i],LP[i]),order:i===1?12:40})"),
 ("tests.push({value:fsub(L[1],[beta,zero]),order:40}","tests.push({value:fsub(L[1],[beta,zero]),order:12}"),
 ('for(let m of [1,40])coeffs[m]','for(let m of [1,12,40])coeffs[m]'),
 ("const n=co.length-1,split=n===9?5:n===7?4:null;","const n=co.length-1,split=n===9?5:n===5?3:n===2?1:null;\n if(n===2){const q2=rsq(name+'.power2',q); return saveF(name,[0,1].map(j=>assign(name+'.sum.'+j,add(co[0][j],mul(co[1][j],q),mul(co[2][j],q2)))));}"),
 ("let w=fmul('detector'+r+'.W',evalSym('detector'+r+'.E1',coeffs[1],q1),evalSym('detector'+r+'.E40',coeffs[40],q40));","let w=fmul('detector'+r+'.W',fmul('detector'+r+'.Wfirst',evalSym('detector'+r+'.E1',coeffs[1],q1),evalSym('detector'+r+'.E12',coeffs[12],q12)),evalSym('detector'+r+'.E40',coeffs[40],q40));")]
for old,new in edits:
 assert original.count(old)==1
 original=original.replace(old,new)
assert original==(W/'03-depth/beta12/build_source.cjs').read_text()
rebuild=H/'depth-rebuild';(rebuild/'sources').mkdir(parents=True,exist_ok=True)
(rebuild/'build_source.cjs').write_text(original)
sourcefile=src/'sources/diophantine_optimization_20261106_v3.tex'
(rebuild/'sources'/sourcefile.name).write_bytes(sourcefile.read_bytes())
subprocess.run(['node',str(rebuild/'build_source.cjs')],check=True,stdout=(H/'depth-source-rebuild.log').open('w'))
for name in ['raw-ir.json','raw-translated-ir.json','census.json']:
 assert read(rebuild/name)==read(W/'03-depth/beta12'/name),name

# Relocate the existing read-only replay driver; its only edit is its root path.
driver=(S/'depth_recheck.py').read_text()
old="ROOT=HERE.parent/'03-depth'";assert driver.count(old)==1
driver=driver.replace(old,'ROOT=Path('+repr(str(W/'03-depth'))+')')
(H/'replay_depth.py').write_text(driver)
subprocess.run([sys.executable,'-B',str(H/'replay_depth.py')],check=True,stdout=(H/'depth-replay.log').open('w'))
write(H/'FINITE-REVIEW.json',{'finiteAuditPassed':True,'candidateSha256':sha(S/'candidate505-ir.json'),
 'certificateSha256':sha(S/'certificate505.json'),'reviewedSources':pins,'patches':audit,
 'depthRawRebuiltExactly':True,'depthCertificateReplayed':True,
 'allFinalResidualsReconstructedFromPinnedPatches':True,'allCoordinateIdsAndNamesChecked':True,
 'onlyAnchorConsumesFixedCoefficient':True,
 'arithmeticProjectionProofAcceptedByThisFiniteCheck':False})
print('Finite source and composition audit passed; arithmetic acceptance is separate.')
