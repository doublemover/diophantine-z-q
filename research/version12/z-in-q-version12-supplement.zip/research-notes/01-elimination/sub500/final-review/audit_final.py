"""Audit the frozen498 composition, building on the earlier frozen505 review."""
import json,hashlib,subprocess,sys,copy
from pathlib import Path
from fractions import Fraction as Q
from functools import reduce
from math import gcd,lcm
H=Path(__file__).resolve().parent;S=H/'snapshot';W=H.parents[2]
R=W.parent/'quartic-version6-release/repository'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,o):(H/n).write_text(json.dumps(o,indent=2)+'\n')
def p(ts):
 q={}
 for t in ts:
  m=tuple(t['monomial']);assert m==tuple(sorted(m))
  k=t.get('sPower',0),m;q[k]=q.get(k,Q(0))+Q(t['coefficient'])
 return {k:v for k,v in q.items() if v}
def table(d):
 c={x['id']:x for x in d['coordinates']};names={x['name'] for x in c.values()}
 r={x['name']:p(x['terms']) for x in d['residuals']};ids={x['id'] for x in d['residuals']}
 assert len(c)==len(names)==len(d['coordinates'])
 assert len(r)==len(ids)==len(d['residuals'])
 assert {v for row in r.values() for s,m in row for v in m}==set(c)
 assert c[0]['name']=='input' and c[0]['protected']
 assert max(len(m) for row in r.values() for s,m in row)<=2
 return c,r
targets=[505,504,501,499,498]
data={n:read(S/f'candidate{n}-ir.json') for n in targets}
tabs={n:table(data[n]) for n in targets}
assert sha(S/'candidate505-ir.json')=='bd9aca7a4a31476e426660d1a33de33552f2a5019bec06104b45938d59f4b966'
assert sha(S/'candidate498-ir.json')=='7682a1229149c75e27322e86dec424449b55321b06c48e468f90fa78bcebb61a'
assert all(data[n]['fixedParameter']=={'name':'C','value':'3^(2^25)','coordinate':False} for n in targets)
certs={n:read(S/f'certificate{n}.json') for n in targets[1:]}
sourcepaths={504:W/'08-denominators/candidate-521-ir.json',501:W/'07-toric/mixed/candidate516.json',
             499:W/'04-charts/further-scalar-cancel/candidate502-ir.json',
             498:W/'01-elimination/sub500/from501/elimination500-certificate.json'}
keys={504:'proposal08Sha256',501:'toricSourceSha256',499:'source502Sha256',498:'sourceCertificateSha256'}
changes=[]
for prev,n in zip(targets,targets[1:]):
 cert=certs[n];assert sha(S/f'candidate{prev}-ir.json')==cert[f'source{prev}Sha256']
 assert sha(sourcepaths[n])==cert[keys[n]]
 assert sha(S/f'candidate{n}-ir.json')==cert['statistics']['candidateSha256']
 assert sha(S/f'polynomial{n}.json')==cert['statistics']['polynomialSha256']
 c0,r0=tabs[prev];c1,r1=tabs[n]
 deleted=set(r0)-set(r1);added=set(r1)-set(r0);changed={name for name in set(r0)&set(r1) if r0[name]!=r1[name]}
 removed=set(c0)-set(c1);new=set(c1)-set(c0)
 if n==504:
  assert deleted==set(cert['deletedRows']);assert changed==set(cert['changedRows'])
  assert removed==set(cert['removedCoordinates']) and len(new)==7 and len(added)==7
  assert all(name.startswith('scalar.shiftedS.reciprocal.') for name in added)
  assert all(c1[v]['name'].startswith('scalar.shiftedS.reciprocal.') for v in new)
  assert all(not({v for s,m in r for v in m}&removed) for name,r in r0.items() if name not in deleted|changed)
 elif n==501:
  assert deleted==set(cert['deletedRows']) and not changed and not new
  assert removed==set(cert['removedCoordinates']) and len(added)==21
  assert all('.toric.' in name for name in added)
  assert sha(W/'03-depth/beta12/final/candidate-ir.json')==cert['depthSourceSha256']
 elif n==499:
  assert deleted==set(cert['deletedRows']);assert changed==set(cert['changedRows'])
  assert removed==set(cert['removedCoordinates']) and not added and not new
  assert all(not({v for s,m in r for v in m}&removed) for name,r in r0.items() if name not in deleted|changed)
 else:
  op,=cert['operations'];assert removed=={op['coordinate']} and not new and not added
  oldids={r['id']:r['name'] for r in data[prev]['residuals']}
  assert deleted=={oldids[op['pivot']]};assert changed=={oldids[z['row']] for z in op['changes']}
  assert cert['operations']==read(sourcepaths[n])['operations']
  assert sha(S/'candidate501-ir.json')==cert['source501Sha256']
 renamed={str(v):[c0[v]['name'],c1[v]['name']] for v in set(c0)&set(c1) if c0[v]['name']!=c1[v]['name']}
 if n!=501:assert not renamed
 else:
  patch=read(sourcepaths[n]);expected={c['sourceId']:c['name'] for c in patch['coordinates']}
  assert len(renamed)==15
  for v in set(c0)&set(c1):
   if str(v) in renamed:assert c1[v]['name']==expected[v] and '.toric.' in c1[v]['name']
   else:assert c1[v]['name']==c0[v]['name']
 changes.append({'from':prev,'to':n,'deletedRows':sorted(deleted),'changedRows':sorted(changed),'addedRows':sorted(added),
                 'removedCoordinates':sorted(removed),'newCoordinates':sorted(new),'renamedCoordinates':renamed,
                 'sourcePatch':str(sourcepaths[n]),'sourcePatchSha256':sha(sourcepaths[n])})

# Rerun the producer-free checkers in the copied snapshot. Relocate only their
# fixed source paths, leaving the equations and assertion bodies unchanged.
replays=[]
for n in targets[1:]:
 origin=S/f'verify{n}.py';text=origin.read_text();edits=[]
 if n in (504,499):
  old="R=H.parents[1]/'quartic-version6-release/repository'";assert text.count(old)==1
  text=text.replace(old,'R=Path('+repr(str(R))+')');edits.append('repository path')
  old="H.parent/'03-depth/beta12/final/candidate-ir.json'";assert text.count(old)==1
  text=text.replace(old,'Path('+repr(str(W/'03-depth/beta12/final/candidate-ir.json'))+')');edits.append('depth semantic-value path')
 replay=S/f'replay{n}.py';replay.write_text(text)
 subprocess.run([sys.executable,'-B',str(replay)],check=True,stdout=(H/f'replay{n}.log').open('w'))
 replays.append({'verifier':str(origin),'sha256':sha(origin),'pathOnlyEdits':edits})

ordinary=None
if (S/'candidate514-ir.json').exists():
 d=read(S/'candidate514-ir.json');cs,rs=table(d);bs,br=tabs[498]
 assert len(cs)==514 and len(rs)==483
 assert all(cs[v]==bs[v] for v in bs)
 chain={c['name']:i for i,c in cs.items() if i not in bs}
 assert set(chain)=={f'constant.c{j}' for j in range(16)}
 last=chain['constant.c15']
 for name,row in br.items():
  expect={}
  for (s,m),v in row.items():
   assert s in (0,1)
   k=0,tuple(sorted(m+(last,)*s));expect[k]=expect.get(k,Q(0))+v
  assert rs[name]==expect
 for j in range(16):
  var=chain[f'constant.c{j}'];right=() if not j else (chain[f'constant.c{j-1}'],)*2
  assert rs[f'constant.definition{j}']=={(0,(var,)):Q(1),(0,right):Q(-3**1024 if not j else -1)}
 assert set(rs)==set(br)|{f'constant.definition{j}' for j in range(16)}
 total={}
 for row in rs.values():
  den=reduce(lcm,(v.denominator for v in row.values()),1);g=reduce(gcd,(abs(int(v*den)) for v in row.values()),0)
  row={k:v*Q(den,g) for k,v in row.items()}
  for (s,m),v in row.items():
   for (t,n),w in row.items():
    k=s+t,tuple(sorted(m+n));total[k]=total.get(k,Q(0))+v*w
 total={k:v for k,v in total.items() if v}
 assert total==p(read(S/'polynomial514.json')['terms'])
 assert max(len(m) for s,m in total)==4 and reduce(gcd,(abs(int(v)) for v in total.values()),0)==1
 assert max(abs(v) for v in total.values())==3**2048+1005072314676622
 ordinary={'coordinates':len(cs),'residuals':len(rs),'monomials':len(total),'uniqueExtension':True,
           'candidateSha256':sha(S/'candidate514-ir.json'),'polynomialSha256':sha(S/'polynomial514.json')}

dump('FINAL-FINITE-REVIEW.json',{'passed':True,'candidateSha256':sha(S/'candidate498-ir.json'),
 'polynomialSha256':sha(S/'polynomial498.json'),'variables':498,'witnesses':497,'residuals':467,'degree':4,'monomials':24669,
 'deltas':changes,'checkerReplays':replays,'ordinary514':ordinary,
 'scope':'Finite composition accepted; independent acceptance of this reviewers own norm identity excluded; arithmetic acceptance separate.'})
dump('SNAPSHOT-SHA256.json',[{'name':p.name,'sha256':sha(p)} for p in sorted(S.iterdir()) if p.is_file() and not p.name.startswith('replay')])
print('Frozen498 finite composition checks passed. Ordinary lift:',ordinary)
