# Exact elimination search, November 7, 2026

No smaller quartic was found. The verified baseline remains 523 total rational
coordinates, 522 witnesses, 492 quadratic residuals, degree four, and 35,163
nonzero monomials. This is a negative search result, not an optimality claim.
No proposed improvement is awaiting acceptance, and no independent review of
this report has yet occurred.

## Frozen input and scope

The input is `baseline523.json`, copied without modification from
`quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json` in the public
checkout. Its SHA-256 is
`48a8b8f9263a97d3a1c59f3f0f3553eae628b7aba342d44003e8da840ae84928`.
The fixed coefficient remains S = 3^(2^26). It is never a coordinate and was
never expanded in decimal.

The source material inspected includes the repository AGENTS.md, the audit
integration protocol, the 523/540 README and addition.tex, the final elimination
and table verifiers, the source reproduction scripts, and the Version 9 final
projection argument in `manuscripts/quartic_v11.tex`. The manuscript hash at
verification time was
`1210d2e6f409e502fc9c95afc248fac16a9df48c760a396143780c20ec80b662`.
The investigation changes no arithmetic premise, theorem application, guard,
projection, or manuscript. It does not independently certify the inherited
arithmetic argument or the concurrent Kato repair.

## Exact structural obstruction

`search.py` and `affine_obstruction.py` computed over rational numbers:

* Every direct constant-pivot substitution fails to keep all residuals quadratic.
* The 492 homogeneous quadratic parts have rank 492. Thus no nonzero constant
  linear combination of the residuals is affine linear.
* The matrix obtained by stacking the 523-column Hessian matrices has rank 523.
  Its 3,176 nonzero rows have no common null direction.

These facts rule out a particular broader class of elimination. After any
invertible affine coordinate change and invertible constant row operation,
suppose a residual has the form a*x + q(y), with a a nonzero rational constant.
It cannot have affine q, because the quadratic parts are independent. Therefore
q has a nonzero quadratic part. If substituting x = -q/a into every other
quadratic residual leaves degree at most two without using equations modulo
the retained ideal, then each other residual has zero x^2 coefficient. Its
quartic term would otherwise be a nonzero multiple of q_2^2. Its x*y terms
must also vanish, since their cubic contribution is q_2 times a linear form,
and the polynomial ring is an integral domain. The pivot itself has no
quadratic x terms. The eliminated direction would consequently be in the
common Hessian kernel, contradicting rank 523.

This obstruction concerns direct substitutions. It does not exclude reduction
modulo retained equations, rational changes of coordinates, replacing a whole
block, or exploiting the rational zero set rather than polynomial identities.

## Bounded searches beyond that obstruction

The adapted upstream modulo search tested 396 pivot choices in each of six
deterministic variable orders, 2,376 attempts total. It used constant pivots
and exact reductions by unaffected quadratic residuals. It found no deletion.
Its certificate has an empty operation list.

`macaulay_search.py` then tested all 396 pivot choices by a different exact
method. For each substituted affected row, it built a space of polynomial
multiples of unaffected residuals connected to its high-degree monomials.
The multipliers are obtained by dividing those monomials by quadratic terms
of retained rows. Rational linear algebra cancels the degree-three and
degree-four parts, and any candidate remainder is reconstructed and checked
exactly. The final run used a 10,000-generator cap. The specified closure
finished in 390 cases and hit its cap in six. No deletion resulted. An earlier
400-generator run also found none. The recorded final run took about 25 seconds.

This is deliberately not described as a full Groebner-basis or elimination-
ideal calculation. The generation rule does not include every possible
bounded-degree ideal multiple, and separate sparse-elimination size limits
also apply. A failed search is not proof of nonmembership in the full ideal.

`inverse_search.py` extracted 13 already-present scalar inverse descriptions
and tested 27 nonconstant pivots whose linear coefficient has one of those
retained inverses. Five gave quadratic replacements after exact reduction;
none kept every remaining residual quadratic. No guard was dropped, and no
nonzero denominator was assumed without a retained inverse equation.

## Projection preservation of the tested transformations

The constant-pivot method would delete a residual a*x + q = 0 only after
substituting x = -q/a. Every changed retained row must equal its substitution
plus explicit polynomial multiples of unaffected retained rows. Forward,
restrict an old zero and use those identities. Reverse, insert x = -q/a;
the retained rows used in the identities still vanish, so every old row and
the pivot vanish. The rational input coordinate is protected throughout.

For an inverse-assisted pivot b*x + r = 0, the retained inverse relation
b*u = 1 gives the equivalent replacement x = -r*u. Its two implications
follow by multiplication with u or b, respectively. The same retained-row
identities must then certify all substitutions. No successful full
transformation was found, so no new polynomial or forward/reverse certificate
is claimed.

Over the rational numbers a sum of squares vanishes exactly when each
quadratic residual vanishes. Nonzero rational row normalization leaves the
zero set unchanged. These are the only facts needed to pass between the
residual system and its quartic.

## Baseline reconstruction and reproducibility

`verify_baseline.py` normalizes every frozen residual to its primitive integer
form, expands all 492 squares by exact arithmetic in Q[S], and compares every
coefficient and coordinate mapping with the published table. It matched
exactly. Both formal and specialized monomial counts are 35,163; in this table
each coordinate monomial has only one nonzero S-power coefficient. The largest
formal integer coefficient has 1,520 bits. The table hash is
`6a3685980de4512bdc7f3a781d0c0d4b32cce5829ec83f03f318264931bdbbe3`.

Run these commands sequentially from this directory with Python 3.10 or newer:

```text
python -B search.py
python -B affine_obstruction.py
python -B modulo_search.py 6
python -B macaulay_search.py 10000
python -B inverse_search.py 10000
python -B verify_baseline.py
```

No external Python package or network access is required. On this workstation
the usable executable was `C:/Users/glaze/.local/bin/python3.14.exe`; the
WindowsApps `python.exe` alias did not launch. The source checkout must remain
at the relative location used by `verify_baseline.py` for the table comparison.
All writes are confined to this approach's directory. There was at most one
Python worker at a time. The generated `candidate-ir.json` and
`macaulay-candidate-ir.json` retain all 523 coordinates and are unchanged systems,
not new records.
