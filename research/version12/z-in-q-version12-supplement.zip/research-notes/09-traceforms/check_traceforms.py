"""Exact finite checks for the bounded trace/norm encoding investigation."""
from collections import Counter
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / 'quartic-version6-release' / 'repository'
BASE = REPO / 'quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json'

def add(*ps):
    out = {}
    for p in ps:
        for m, c in p.items():
            out[m] = out.get(m, Q(0)) + c
    return {m: c for m, c in out.items() if c}

def scale(p, c):
    return {m: c*v for m, v in p.items() if c*v}

def mul(p, q):
    out = {}
    for m, c in p.items():
        for n, d in q.items():
            k = tuple(sorted(m+n))
            out[k] = out.get(k, Q(0)) + c*d
    return {m: c for m, c in out.items() if c}

def sub(p,q): return add(p,scale(q,-1))
def sq(p): return mul(p,p)
def var(i): return {(i,):Q(1)}
def degree(p): return max(map(len,p),default=0)
def subst(p,x,q):
    out={}
    for m,c in p.items():
        z={tuple(i for i in m if i != x):c}
        for _ in range(m.count(x)): z=mul(z,q)
        out=add(out,z)
    return out

def readrow(row):
    # The investigated arithmetic rows have no S. Keep it a formal variable
    # for whole-system checks; degree bookkeeping below counts it as constant.
    assert all(t.get('sPower',0)==0 for t in row['terms'])
    return {tuple(t['monomial']):Q(t['coefficient']) for t in row['terms']}

def fmul(a,b,d=2):
    return (add(mul(a[0],b[0]),scale(mul(a[1],b[1]),d)),
            add(mul(a[0],b[1]),mul(a[1],b[0])))
def norm(a,d=2): return sub(sq(a[0]),scale(sq(a[1]),d))

a,b,c,e=map(var,range(4))
z=fmul((a,b),(c,e))
assert norm(z)==mul(norm((a,b)),norm((c,e)))
assert degree(z[0])==degree(z[1])==2
assert degree(norm(z))==4
# Distinct quadratic supports certify independence of the two output forms.
assert set(z[0]).isdisjoint(z[1])
zz=fmul((a,b),(a,b))
assert set(zz[0]).isdisjoint(zz[1])
# Trace(x^2)/2 and norm(x) have the advertised signatures.
assert zz[0]==add(sq(a),scale(sq(b),2))
assert norm((a,b))==sub(sq(a),scale(sq(b),2))
# Nonzero residuals whose norms cancel.
def qnorm(x,d=2): return x[0]**2-d*x[1]**2
assert qnorm((1,0))+qnorm((1,1))==0
# Same trace and norm, distinct field elements.
assert qnorm((3,1))==qnorm((3,-1))==7
# Split-place test counterexample: norm one, but valuations +1 and -1 above 7.
assert qnorm((Q(11,7),Q(6,7)))==1

data=json.loads(BASE.read_text())
rows={r['id']:readrow(r) for r in data['residuals']
      if not any(t.get('sPower',0) for t in r['terms'])}
row_names={r['id']:r['name'] for r in data['residuals']}
interesting=('symmetric.','testSquare.','logV','heightProduct.','Lucas.')
direct_checks=[]
for coord in data['coordinates']:
    x=coord['id']
    if not coord['name'].startswith(interesting): continue
    assert all(not any(x in t['monomial'] for t in r['terms'])
               for r in data['residuals'] if r['id'] not in rows)
    pivots=[]
    for rid,p in rows.items():
        if (x,) in p and all(x not in m or m==(x,) for m in p):
            # Genuine source assignment, not arbitrary linear occurrence.
            if row_names[rid].replace('.definition','') != coord['name'].replace('.quadratic',''):
                continue
            q=scale({m:c for m,c in p.items() if m!=(x,)},-1/p[(x,)])
            if degree(q)>2: continue
            bad=[]
            for sid,r in rows.items():
                if sid!=rid and any(x in m for m in r):
                    deg=degree(subst(r,x,q))
                    if deg>2:bad.append({'id':sid,'name':row_names[sid],'degree':deg})
            pivots.append({'pivot':rid,'badConsumers':bad})
    if pivots:direct_checks.append({'coordinate':x,'name':coord['name'],'pivots':pivots})

report={
    'scope':'bounded local encodings and direct substitution; no global optimality claim',
    'files':{str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest()
             for p in [BASE,REPO/'manuscripts/quartic_v11.tex',
                       REPO/'docs/quartic-523-540/addition.tex',
                       REPO/'quartics/quartic-523-540/source-reproduction/builders/odd-product-asymmetric-source.cjs']},
    'baselineCoordinates':len(data['coordinates']),
    'baselineResiduals':len(data['residuals']),
    'blockCoordinates':dict(sorted(Counter(c['block'] for c in data['coordinates']).items())),
    'identitiesVerified':['norm multiplicativity','independent product components',
        'independent square components','positive trace square','norm cancellation counterexample',
        'trace/norm conjugate ambiguity','split-place norm-one counterexample'],
    'terminalNormRewrite':{'originalCoordinates':3,'replacementCoordinates':4,'saving':-1},
    'directAssignmentCount':len(direct_checks),
    'directAssignmentChecks':direct_checks,
    'directlyEliminableInExaminedSet':[x['name'] for x in direct_checks
        if any(not p['badConsumers'] for p in x['pivots'])],
    'acceptedCandidate':None,
    'variableSaving':0,
}
assert len(direct_checks)==157
assert not report['directlyEliminableInExaminedSet']
(HERE/'check-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('directAssignmentChecks','files')},indent=2))
