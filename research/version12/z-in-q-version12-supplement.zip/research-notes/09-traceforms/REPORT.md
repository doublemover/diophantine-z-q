# Trace and norm encodings for the 523-variable quartic

This investigation found no variable saving within the local replacements described below. It does not prove that 523 is optimal. The result is an explicit set of obstructions, one exact circuit comparison, and a reproducible direct-substitution check of 157 current assignment coordinates. No manuscript or shared source was changed. Independent acceptance remains pending.

## Source and conventions

The actual field in the current construction is `K = Q(sqrt(2))`, not `Q(sqrt(5))`. This is stated in `docs/quartic-523-540/addition.tex`, in its inherited-input conventions and chart section, and implemented by `rawFmul`, `fmul`, and `fquot` in `quartics/quartic-523-540/source-reproduction/builders/odd-product-asymmetric-source.cjs`. The analogous elementary identities below hold with any positive nonsquare `d` replacing 2, but changing the field of the arithmetic construction is not justified.

The inspected final object is `final523_540/symbolic523/candidate-ir.json`, with 523 rational coordinates and 492 residuals. The checksum report pins this file, the builder, the addition, and `manuscripts/quartic_v11.tex`. The manuscript uses the same field and its section on private conic packing explicitly distinguishes selected split branches. This work neither changes those arithmetic inputs nor claims a new validation of them.

I applied the local `unslop` writing guidance. No Lean skill applies to these rational polynomial checks.

## 1. Pairing coefficient equations does not save a coordinate

Let a field residual be `E = E0 + E1 sqrt(2)`, with each coefficient a rational polynomial of degree at most two. The positive trace form is

```
Tr(E^2)/2 = E0^2 + 2 E1^2.
```

It has degree at most four and vanishes over Q exactly when both coefficient residuals vanish. Taking the sum of these positive forms therefore gives a valid quartic. This uses exactly the same variables as the existing sum of coefficient squares. Changing the relative weights of those squares changes coefficients, not witness count.

The field norm `N(E) = E0^2 - 2 E1^2` also vanishes exactly when E is zero, since sqrt(2) is irrational. It cannot replace each pair followed by ordinary summation. For example, `E = 1` and `F = 1 + sqrt(2)` are both nonzero, but `N(E) + N(F) = 1 - 1 = 0`. Squaring each norm restores a nonnegative sum but raises the generic degree from four to eight. The exact checker verifies the counterexample and identities.

This rules out a saving from the specific operations “replace a coefficient pair by its trace square” and “sum the field norms.” It does not rule out all specially designed quartics.

## 2. One generic multiplication output cannot replace two

For input pairs `(a,b)` and `(c,e)`, multiplication has coefficient outputs

```
M0 = ac + 2be,
M1 = ae + bc.
```

These homogeneous quadratic forms are linearly independent over Q. Their monomial supports are disjoint. A circuit that stores one new quadratic scalar `g` and recovers both outputs by affine rational expressions in `g,a,b,c,e` would make the quadratic parts of M0 and M1 scalar multiples of the quadratic part of g. This contradicts their independence. Thus two output coordinates are necessary in this restricted, standard assignment model. The existing `fmul` attains that number.

The same argument applies to squaring, whose outputs are `a^2+2b^2` and `2ab`. It also covers any invertible rational change of coefficient basis. Replacing the basis by one involving sqrt(2) in its rational coordinates would change the coefficient field and is not an allowed rational encoding.

This is a local statement. It does not assert a lower bound when outputs are never separately consumed, when nonlinear decoding is allowed, or when an entire collection of gates is redesigned.

## 3. Trace and norm do not encode the signed coefficient

Storing trace and norm uses two scalar values, so it has no immediate count advantage. It also forgets conjugation. The distinct inputs `3+sqrt(2)` and `3-sqrt(2)` both have trace 6 and norm 7. Recovering the missing coefficient requires choosing a sign, and a branch-sensitive multiplication cannot use the pair unambiguously. For example, multiplication by `1+sqrt(2)` gives rational components 5 and 1 respectively.

The ambiguity is harmless only after proving the entire downstream expression is conjugation invariant. The current builder consumes both components throughout the logarithms, field quotients, symmetric coefficients, and selected-conjugate tests. Merely replacing these pairs by trace and norm supplies no such proof.

In particular, Cayley-Hamilton identities such as `x^2 - Tr(x)x + N(x) = 0` do not alone reduce the number of generic square outputs. They require the existing pair x and the new norm coordinate, and their use in a larger polynomial circuit must be counted separately. This investigation does not claim an optimal circuit for every logarithm polynomial.

## 4. A terminal norm-product replacement costs one extra coordinate

Consider the detector endpoint before any unrelated eliminations. Write its two field factors as `A` and `B`, its product as `W`, and its rational output as n. The current local circuit stores `W0,W1,n` and imposes

```
W0 = A0 B0 + 2 A1 B1,
W1 = A0 B1 + A1 B0,
2 W0 n = W0^2 - 2 W1^2.
```

The retained nonzero guard on W0 is unchanged. Norm multiplicativity suggests deleting W1, but preserving quadratic residuals then requires

```
NA = A0^2 - 2 A1^2,
NB = B0^2 - 2 B1^2,
W0 = A0 B0 + 2 A1 B1,
2 W0 n = NA NB.
```

This circuit has four coordinates `NA,NB,W0,n`, compared with three. It is equivalent in both directions when the same inputs and guard are retained: norm multiplicativity gives the old last equation, while the omitted W1 is uniquely reconstructed as `A0 B1+A1 B0`. Without NA and NB, the last residual has degree four and its square has degree eight. Thus this particular exact rewrite loses one coordinate per detector. This is a comparison of local circuits, not a claim that all four new coordinates survive any possible subsequent global optimization.

The checker verifies the polynomial identity `N(AB)=N(A)N(B)` exactly. No inverse-guard optimization is claimed here; those were explicitly reserved for other work.

## 5. Norms cannot replace selected split-branch tests

At the two places above 7, the element `3+sqrt(2)` has valuations `(1,0)` in a suitable order, because its norm is 7 and the two conjugate factors cannot both vanish modulo 7. Therefore

```
F = (3+sqrt(2))/(3-sqrt(2)) = (11+6sqrt(2))/7
```

has valuations `(1,-1)` and norm 1. A norm-only test sees a unit and loses both the selected vanishing and the opposite pole. The same example with its conjugate reverses the selected branch while retaining the same norm.

The trace of F is 22/7, whose 7-adic valuation is -1. Requiring trace integrality in place of one-branch integrality would exclude this perfectly valid one-branch input. The source construction's selected branch conditions therefore cannot be replaced by a universal norm-integrality or trace-integrality assertion. Its real positivity cannot repair this loss of p-adic information.

This counterexample addresses a proposed universal algebraic replacement. It does not claim that this exact F is attained by a particular elliptic witness in the source system.

## 6. Check against the compiled residual system

The script checks every surviving quadratic assignment coordinate under these name prefixes for direct substitution into its consumers:

| Family | Assignments checked |
| --- | ---: |
| Shared symmetric coefficients | 70 |
| Five logarithm blocks | 50 |
| Test squares | 22 |
| Height product and scales | 9 |
| Lucas arithmetic | 6 |
| Total | 157 |

Every checked coordinate has at least one consumer whose exact substituted polynomial has degree greater than two. None can simply be removed while retaining the current sum-of-squares quartic construction. The output records each pivot and every obstructing consumer, with its resulting degree. This test does not use other residuals to reduce degree and does not search changes of variables, so it is not a general elimination impossibility result.

Run with the supplied Python runtime or any standard Python 3 installation:

```
python -B check_traceforms.py
```

The script uses only the standard library, writes only `check-results.json` beside itself, and reads the pinned repository sources. It does not invoke the source builder, whose normal output location would otherwise be inside the source tree.

The bounded conclusion is zero demonstrated savings. The promising work left outside this result is a redesign of whole simultaneous-test or logarithm circuits with explicit branch information and degree accounting. A smaller polynomial from such a redesign still needs reversible witness maps and independent acceptance.
