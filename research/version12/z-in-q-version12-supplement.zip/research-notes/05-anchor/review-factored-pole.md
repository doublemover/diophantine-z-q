# Independent review of the factored detector poles

I accept the factored-pole transformation from the frozen 501-variable source
to the proposed 498-variable system, conditional on the inherited arithmetic
inputs and the source's established completeness construction. The required
positive-pole witnesses are supplied by that construction. Positivity is not
being inferred for arbitrary solutions, and it is not a new equation or a
new arithmetic assumption.

I did not author this transformation. This is independent internal model
review of the relative change, not a new review of the global arithmetic
theorem or of every prior transformation in the 501 source.

## Reviewed artifacts

The source `10-combination/candidate501-ir.json` has SHA-256
`6a31040f85e30cc6f9d076bf6c92218be110e0829e93333d7e99f93a6b2f0d9a`.
The target `02-squares/factored/candidate498-ir.json` has SHA-256
`0b72432400cb01cb1531a26ca370ee5988bd8b8d9537aaa8640a3e98f4cfabba`.
The target polynomial has SHA-256
`59ad8e3bdcd761590dc2eeecc772344f4ebade5001482364e27e04e4744ea927`.
The reviewed factored-pole report has SHA-256
`d61011221ab6bce5d98febea7c5cfeba909bc05e0dfbf1d683e4b80af104e89e`.

I read the report, producer, verifier, actual source and target rows, and the
manuscript's detector definitions and completeness proof. The current
manuscript hash is
`1210d2e6f409e502fc9c95afc248fac16a9df48c760a396143780c20ec80b662`.

## Exact witness maps

For one normalized source detector, denote its private coordinates by
E,t,q,t2,q2,F. Its relevant rows are

    A = 17E-Eb-17F,
    B = t^2-t2,
    C = q^2-q2,
    D = 17b*q2+867F^2-34F*t2-t2^2.

The proposed rows, using private v,Q,Q2 in the old F,q,q2 slots, are

    A' = 17E-Eb-17t*v,
    C' = Q^2-Q2,
    D' = 17b*Q2+867v^2-34t*v-t^2.

The factor 17 is correct for the compiler's F coordinate. It is not legitimate
to replace F by an unnormalized mathematical Bh without that factor.

For every new rational solution, reconstruct

    F=t*v, q=t*Q, q2=t^2*Q2, t2=t^2.

Then A=A', B=0, C=t^2*C', D=t^2*D'. These are polynomial identities, including
at t=0 and for negative or zero b. They prove soundness without dividing by
t or assuming positivity. Every other source coordinate is preserved.

For completeness, choose a source solution with all three b positive. If
t!=0, set v=F/t, Q=q/t, Q2=q2/t^2 and delete t2. The four source equations
give all three target equations by legitimate rational division.

If t=0, the source gives t2=0, q2=q^2 and

    17b*q^2+867F^2=0.

Both terms are nonnegative, and their coefficients are strictly positive.
Thus F=q=q2=0. Set v=Q=Q2=0. The target C' and D' vanish, while A' is precisely
the already satisfied source equation with F=0. E, b, t, the first conic and
all outside coordinates remain unchanged. No nonzero condition on t has
been added, and no degenerate source case has been discarded.

For b<0 a source solution with t=0 may have F or q nonzero, so these formulas
are not an inverse on every old fixed-b fiber. The report correctly avoids
that stronger claim. Equality of input projections follows instead from
the unconditional new-to-old map and the positive-b completeness lift.

## Why the required positive witnesses exist

In Version 11, `eq:v5-detector-product` defines the actual detector input
B_r=R_r/T_r^2. The compiler coordinate `detector{k}.B` is B_r itself; the conic
parameter is 17B_r. This distinction matters for the positivity application.

The completeness proof around lines 11313-11328 obtains, for fixed positive
scale A_r and lambda tending to positive infinity,

    R_r ~ A_r^(-6)/lambda,
    W_r = 1+O(lambda^(-3)),
    T_r = 2+O(lambda^(-3)),
    B_r ~ 1/(4 A_r^6 lambda).

The text explicitly concludes 0<B_r<17 before filling the preparation-zero
pole. The `v5:preparation-zero-bridge` hypothesis is also explicitly positive
b. Thus its rational witnesses are constructed for the same positive value
consumed here, not merely for a related parameter or squareclass.

Version 9's product-height scales are positive rational squares. Its
`subsec:v9-completeness` and `subsec:v9-deep-completeness` retain these real
bounds and the pole construction. The mixed-order logarithm change retains
the same bounded real tests and lambda^(-3) estimate. The actual composed
501 route retains the same property: the earlier pole normalization keeps
b unchanged; the trace guards retain the real-progression selection; the
anchor and scalar preparations occur before fixing the roots and scales;
and the Laurent-chain and scalar reciprocal replacements preserve the
outside coordinates, including b. They transport the already chosen
positive-pole witnesses rather than requiring a new choice with uncontrolled
sign.

Consequently the completeness construction gives one source501 solution
with all three b positive for every integer input. The new lifts can be
performed simultaneously because their private coordinates are disjoint.
There is no new prime-pattern condition and no change in the order of the
global choices.

## Mechanical and consumer checks

`review_factored_check.py` is a separately written checker that imports no
producer or verifier from the proposal. It reconstructs the nine target
rows directly from coordinate names, checks the t=0 residual and zero lift,
and substitutes all three polynomial witness maps simultaneously into every
one of the 470 source rows. The result is exactly the corresponding target
row, its specified t^2 multiple, or zero for a deleted t-square definition.

This complete row check includes hidden consumers. In particular, F,q,q2,t2
have no unaccounted use outside the displayed private pole rows. The first
conic, detector input, weights, comparison tests and all scalar equations
are preserved. The actual incidence lists are recorded in
`review-factored-checks.json`.

Exactly the three t2 coordinates and their definitions are removed. The
remaining 467 rows are quadratic in 498 coordinates, including the input.
The independent sum-of-squares expansion matches every saved coefficient.
The resulting quartic has 24,712 coordinate monomials. The fixed parameter
remains C=3^(2^25); the anchor's coefficient 16C^2 remains the largest one.
The changed detector rows introduce only the displayed small integer
coefficients, and do not involve C.

The input-projection conclusion is therefore valid relative to source501:
new solutions reconstruct old solutions for soundness, and the actual
source completeness witnesses admit the explicit new lift. No shared
manuscript, source artifact, or acceptance record was modified. This review
does not establish priority of the factorization or reclassify any earlier
historical audit.
