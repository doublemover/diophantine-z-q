"""Build and check the 522-coordinate, single-coefficient anchor candidate.

Only standard library; no expansion of S=3**(2**26). The local argument for
all indices is in REPORT.md; finite arithmetic checks are not its proof.
"""
from pathlib import Path
from fractions import Fraction as Q
from math import gcd, lcm
from functools import reduce
import copy, hashlib, json
import random

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent / 'quartic-version6-release' / 'repository'
SRC = REPO / 'quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json'
SOURCE_SHA = '48a8b8f9263a97d3a1c59f3f0f3553eae628b7aba342d44003e8da840ae84928'
assert hashlib.sha256(SRC.read_bytes()).hexdigest() == SOURCE_SHA
src = json.loads(SRC.read_text())
rows = {r['id']: r for r in src['residuals']}
assert len(src['coordinates']) == 523 and len(rows) == 492
assert [r['id'] for r in src['residuals'] if any(539 in t['monomial'] for t in r['terms'])] == [507,508]
assert [r['id'] for r in src['residuals'] if any(set(t['monomial']) & {55,56,57} for t in r['terms'])] == [508]
assert src['values']['Sscalar.f.1']['terms'] == [{'monomial':[509], 'sPower':0, 'coefficient':'1/1'}]

def term(c, m=(), s=0):
    return {'monomial':list(m), 'sPower':s, 'coefficient':str(c)}

new_anchor = {'id':508, 'name':'anchor.singleCoefficient', 'kind':'structural',
              'block':'anchor', 'terms':[term(1,[55,55]), term(6,[56,56]),
                                        term(-2,[57,57]),term(-3,[509,509]),term(2,[],1)]}
out = {'format':'single-coefficient-anchor-quadratic-ir-v1',
       'source':{'path':str(SRC), 'sha256':SOURCE_SHA},
       'fixedParameter':src['fixedParameter'],
       'coordinates':[copy.deepcopy(c) for c in src['coordinates'] if c['id'] != 539],
       'residuals':[copy.deepcopy(r) if r['id'] !=508 else new_anchor
                    for r in src['residuals'] if r['id'] !=507]}
for c in out['coordinates']:
    if c['id'] in {55,56,57}: c['name']='anchor.'+{55:'u',56:'v',57:'w'}[c['id']]

# Normalize every residual to primitive integer coefficients. This gives an
# explicit integer quartic as the sum of the squares of these exact rows.
poly = {}
for r in out['residuals']:
    coeffs = [Q(t['coefficient']) for t in r['terms']]
    den = reduce(lcm, (c.denominator for c in coeffs), 1)
    content = reduce(gcd, (abs(int(c*den)) for c in coeffs), 0)
    for t,c in zip(r['terms'], coeffs): t['coefficient']=str(int(c*den/content))
    for a in r['terms']:
        for b in r['terms']:
            k=(a['sPower']+b['sPower'],tuple(sorted(a['monomial']+b['monomial'])))
            poly[k]=poly.get(k,0)+int(a['coefficient'])*int(b['coefficient'])
poly={k:v for k,v in poly.items() if v}
ids={c['id'] for c in out['coordinates']}
used={v for r in out['residuals'] for t in r['terms'] for v in t['monomial']}
assert used==ids and 0 in ids and len(ids)==522
assert len(out['residuals'])==491
assert max(len(t['monomial']) for r in out['residuals'] for t in r['terms'])==2
assert max(len(m) for s,m in poly)==4
assert reduce(gcd, (abs(c) for c in poly.values()), 0)==1

# S greatly exceeds every fixed coefficient; grouping by coordinate monomial
# cannot turn a nonzero symbolic coefficient into zero at the specified S.
grouped={}
for (s,m),c in poly.items(): grouped.setdefault(m,{})[s]=c
max_fixed_sum=max(sum(abs(c) for c in cs.values()) for cs in grouped.values())
assert max_fixed_sum.bit_length()+2 < 2**26
assert [m for m,cs in grouped.items() if 2 in cs]==[()]
assert grouped[()][2]==4
assert any(cs=={0:1} for cs in grouped.values()) # Actual content one, too.

# Evaluate the independently grouped expansion against the residual sum.
rng=random.Random(522)
for prime in [101,103,107]:
    assignments={v:rng.randrange(prime) for v in ids}
    sval=pow(3,2**26,prime)
    def ev(c,m,s):
        ans=c*pow(sval,s,prime)
        for v in m:ans=ans*assignments[v]%prime
        return ans%prime
    left=sum(sum(ev(int(t['coefficient']),t['monomial'],t['sPower'])
                 for t in r['terms'])**2 for r in out['residuals'])%prime
    right=sum(ev(c,m,s) for (s,m),c in poly.items())%prime
    assert left==right

# Exact arithmetic in Q(sqrt(2)), sufficient to independently verify the
# published local starting direction and several nontrivial even multiples.
def add(a,b): return (a[0]+b[0],a[1]+b[1])
def neg(a): return (-a[0],-a[1])
def mul(a,b): return (a[0]*b[0]+2*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def scale(a,c): return (a[0]*c,a[1]*c)
def inv(a): return scale((a[0],-a[1]),1/(a[0]*a[0]-2*a[1]*a[1]))
def sub(a,b): return add(a,neg(b))
def div(a,b): return mul(a,inv(b))
ONE=(Q(1),Q(0)); D=(Q(11),Q(-6))
P=((Q(57,8),Q(-7,2)),(Q(-165,8),Q(417,32)))
def padd(p,q):
    if p is None:return q
    if q is None:return p
    x,y=p; X,Y=q
    if x==X and y==neg(Y):return None
    slope=div(sub(scale(mul(x,x),3),D),scale(y,2)) if p==q else div(sub(Y,y),sub(X,x))
    xx=sub(sub(mul(slope,slope),x),X)
    return xx,sub(mul(slope,sub(x,xx)),y)
def times(n,p):
    acc=None
    while n:
        if n&1: acc=padd(acc,p)
        n//=2
        if n:p=padd(p,p)
    return acc
def val3(q):
    assert q
    a,b=q.numerator,q.denominator; v=0
    while a%3==0:a//=3;v+=1
    while b%3==0:b//=3;v-=1
    return v
def mod3(q): return (q.numerator*pow(q.denominator,-1,3))%3
p2=padd(P,P); z2=neg(div(*p2))
assert z2==(Q(3396356159088,3287811625151),Q(-4135204317756,3287811625151))
assert tuple(mod3(q/3) for q in z2)==(2,1)
assert tuple(mod3(q) for q in mul((Q(2),Q(1)),(Q(2),Q(1))))==(0,1)
local=[]
for n in [2,4,6,10,12,18]:
    f=inv(times(n,P)[0]); depth=2+2*val3(Q(n))
    assert val3(f[1])==depth and (not f[0] or val3(f[0])>=depth+1)
    assert tuple(mod3(q/(3**depth)) for q in f)==(0,1)
    local.append({'n':n,'v3f0':val3(f[0]),'v3f1':val3(f[1]),'normalizedResidue':[0,1]})

def write(name,obj): (HERE/name).write_text(json.dumps(obj,indent=2)+'\n')
write('candidate522-ir.json',out)
write('polynomial522-symbolic.json',{'fixedParameter':out['fixedParameter'],
      'definition':'Sum of squares of primitive integer residuals in candidate522-ir.json',
      'terms':[term(c,m,s) for (s,m),c in sorted(poly.items())]})

# Alternative affine anchor translation with the smaller parameter C.
small=copy.deepcopy(out)
small['fixedParameter']={'name':'C','value':'3^(2^25)','coordinate':False}
anchor=next(r for r in small['residuals'] if r['id']==508)
anchor['terms']=[term(1,[55,55]),term(6,[56,56]),term(-2,[57,57]),
                 term(-4,[57],1),term(-3,[509,509])]
anchor['name']='anchor.singleCoefficientTranslated'
write('candidate522-smallcoeff-ir.json',small)

# The standard-size coefficient version has only sixteen constant coordinates.
ordinary=copy.deepcopy(small)
ordinary.pop('fixedParameter')
for j in range(16):
    ordinary['coordinates'].append({'id':539+j,'name':f'constant.c{j}','kind':'gate'})
    rr=[term(1,[539+j]),term(-(3**1024))] if j==0 else [term(1,[539+j]),term(-1,[538+j,538+j])]
    ordinary['residuals'].append({'id':509+j,'name':f'constant.definition{j}','terms':rr})
for r in ordinary['residuals']:
    for t in r['terms']:
        if t['sPower']:
            assert t['sPower']==1 and r['id']==508
            t['monomial']=sorted(t['monomial']+[554]);t['sPower']=0
assert len(ordinary['coordinates'])==538
assert len(ordinary['residuals'])==507
assert max(len(t['monomial']) for r in ordinary['residuals'] for t in r['terms'])==2
write('candidate538-ir.json',ordinary)
def expand_stats(data):
    pp={}
    for r in data['residuals']:
        for a in r['terms']:
            for b in r['terms']:
                key=(a['sPower']+b['sPower'],tuple(sorted(a['monomial']+b['monomial'])))
                pp[key]=pp.get(key,0)+int(a['coefficient'])*int(b['coefficient'])
    return {k:c for k,c in pp.items() if c}
spoly=expand_stats(small)
opoly=expand_stats(ordinary)
assert {(s,m):c for (s,m),c in spoly.items() if s==2}=={(2,(57,57)):16}
assert max(map(abs,opoly.values()))==3**2048+1005072314631333
assert max(map(abs,opoly.values())).bit_length()==3247
assert reduce(gcd,map(abs,opoly.values()))==1
summary={'baselineCoordinates':523,'coordinates':522,'witnesses':521,
         'baselineResiduals':492,'residuals':491,'degree':4,
         'coordinateMonomials':len(grouped),'symbolicTerms':len(poly),
         'symbolicContent':1,'constantCoefficientBySPower':grouped[()],
         'maxFixedCoefficientBits':max_fixed_sum.bit_length(),
         'modularExpansionChecks':3,'coefficientOnePresent':True,
         'smallerParameterVariant':'C=3^(2^25); anchor shift w_old=w_new+C',
         'smallerParameterVariantMonomials':len({m for s,m in spoly}),
         'ordinaryVariantCoordinates':538,'ordinaryVariantResiduals':507,
         'ordinaryVariantMonomials':len(opoly),'ordinaryMaxCoefficientBits':3247,
         'checks':local,'sourceSha256':SOURCE_SHA,
         'arithmeticStatus':'New argument; pending independent review; inherited arithmetic inputs unchanged.'}
write('CHECKS.json',summary)
print(json.dumps(summary,indent=2))
