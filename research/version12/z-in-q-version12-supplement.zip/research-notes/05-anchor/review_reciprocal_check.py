"""Independent checks for proposal 08, without importing its producer/checker."""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json
HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent/'quartic-version6-release/repository'
SOURCE=REPO/'quartics/quartic-523-540/final523_540/symbolic523/integer-candidate-ir.json'
CANDIDATE=HERE.parent/'08-denominators/candidate-521-ir.json'
COMBINED=HERE.parent/'10-combination/candidate505-ir.json'

# Generic identities over Z[a,b,h,j]/(j^2-h^4+a^4-b^2).
zero=(0,0,0,0)
def A(*ps):
    out={}
    for p in ps:
        for m,c in p.items():out[m]=out.get(m,0)+c
    return {m:c for m,c in out.items() if c}
def S(p,c):return {m:v*c for m,v in p.items() if v*c}
def M(p,q):
    out={}
    for m,c in p.items():
        for n,d in q.items():
            k=tuple(x+y for x,y in zip(m,n))
            if k[3]<2:out=A(out,{k:c*d})
            else:
                assert k[3]==2
                base=k[:3]+(0,)
                for increment,factor in [((0,0,4,0),1),((4,0,0,0),-1),((0,2,0,0),1)]:
                    out=A(out,{tuple(x+y for x,y in zip(base,increment)):c*d*factor})
    return out
def PW(p,n):
    out={zero:1}
    for _ in range(n):out=M(out,p)
    return out
a,b,h,j=({tuple(int(k==i) for k in range(4)):1} for i in range(4))
x=PW(h,2);c=PW(a,2);D=A(PW(a,4),S(PW(b,2),-1))
d=A(M(c,x),D); N=A(M(a,j),S(M(b,h),-1)); delta=A(x,S(c,-1))
mm=S(A(S(M(M(M(a,D),h),A(x,c)),2),M(M(b,j),A(M(c,x),S(D,-1)))),-1)
ln=A(M(h,j),M(a,b))
identities={
 'curve':A(PW(mm,2),M(D,PW(N,4)),S(PW(d,4),-1)),
 'zero_factor':A(M(N,A(M(a,j),M(b,h))),S(M(delta,d),-1)),
 'abscissa':A(M(A(PW(ln,2),S(M(A(x,c),PW(delta,2)),-1)),PW(N,2)),S(M(PW(delta,2),PW(d,2)),-1)),
 'ordinate':A(M(M(mm,d),delta),S(M(M(ln,A(M(x,PW(N,2)),S(PW(d,2),-1))),N),-1),M(M(M(h,j),PW(N,3)),delta)),
}
q=S(M(a,b),2); e=A(S(PW(a,4),3),S(D,-1));d0=A(PW(a,4),D)
m0=A(S(M(PW(a,4),D),-4),M(PW(b,2),A(PW(a,4),S(D,-1))))
t=A(PW(e,2),S(M(c,PW(q,2)),-2))
y=A(S(M(e,A(M(c,PW(q,2)),S(t,-1))),-1),M(M(a,b),PW(q,3)))
identities['minusP_abscissa']=A(t,S(PW(d0,2),-1))
identities['minusP_ordinate']=A(y,M(m0,d0))
assert all(not p for p in identities.values())

# Independent sparse rational polynomial reconstruction of every changed row.
def pa(*ps):
    out={}
    for p in ps:
        for k,v in p.items():out[k]=out.get(k,Q(0))+v
    return {k:v for k,v in out.items() if v}
def sc(p,c):return {k:v*c for k,v in p.items() if v*c}
def pm(p,q):
    out={}
    for (s,m),v in p.items():
        for (t,n),w in q.items():
            key=(s+t,tuple(sorted(m+n)));out[key]=out.get(key,Q(0))+v*w
    return {k:v for k,v in out.items() if v}
def pc(c):return {(0,()):Q(c)} if c else {}
def var(i):return {(0,(i,)):Q(1)}
def read(ts,trans=None):
    return pa(*[{(t.get('sPower',0),tuple(sorted(trans[i] if trans else i for i in t['monomial']))):Q(t['coefficient'])} for t in ts])
def norm(p):
    first=p[min(p)]
    return sc(p,1/first)
def fa(p,q):return tuple(pa(p[i],q[i]) for i in range(2))
def fs(p,q):return fa(p,tuple(sc(t,-1) for t in q))
def fm(p,q):return (pa(pm(p[0],q[0]),sc(pm(p[1],q[1]),2)),pa(pm(p[0],q[1]),pm(p[1],q[0])))
def fc(a,b=0):return(pc(a),pc(b))
def fscale(p,c):return tuple(sc(t,c) for t in p)
src=json.loads(SOURCE.read_text()); new=json.loads(CANDIDATE.read_text()); comb=json.loads(COMBINED.read_text())
nr={r['name']:read(r['terms']) for r in new['residuals']}
old={r['name']:read(r['terms']) for r in src['residuals']}
names={c['name']:c['id'] for c in new['coordinates']}
def field(name):return tuple(var(names[name+'.'+str(i)]) for i in range(2))
def value(name):return tuple(read(src['values'][name+'.'+str(i)]['terms']) for i in range(2))
aa=fc(-1,Q(7,4));bb=fc(Q(39,8),Q(-9,2));cc=fm(aa,aa);DD=fc(11,-6)
expected={};removed=[]
for prefix,point,fn,on,islog in [('V0','H','V0.f','logV0',True),('scalar.shiftedS','S','Sscalar.f','Sscalar.z',False)]:
    hh,jj,xx=(value(point+'.'+v) for v in ['h','j','x'])
    dd=fa(fm(cc,xx),DD); nn=fs(fm(aa,jj),fm(bb,hh))
    mm=fscale(fa(fscale(fm(fm(aa,DD),fm(hh,fa(xx,cc))),2),fm(bb,fm(jj,fs(fm(cc,xx),DD)))),-1)
    gg=field(prefix+'.reciprocal.g');kk=field(prefix+'.reciprocal.k');d2=field(prefix+'.reciprocal.d2')
    ff=value(fn);oo=value(on);ggout=fm(gg,value('logV0.polynomial')) if islog else gg
    pairs={prefix+'.reciprocal.g.definition':fs(fm(dd,gg),nn),prefix+'.reciprocal.d2.definition':fs(d2,fm(dd,dd)),prefix+'.reciprocal.k.definition':fs(fm(d2,kk),mm),fn+'.definition':fs(ff,fm(gg,gg)),on+'.definition':fa(fm(kk,oo),ggout)}
    for name,pair in pairs.items():
        for i,p in enumerate(pair):expected[name+'.'+str(i)]=p
    expected[prefix+'.reciprocal.f0Inverse.definition']=pa(pm(ff[0],var(names[prefix+'.reciprocal.f0Inverse'])),pc(-1))
    removed += [name for name in old if name.startswith(tuple(prefix+'.'+s for s in ['dxInverse','slope','slopeSquare','yProduct']))]
assert set(nr)==(set(old)-set(removed))|set(expected)
for name,p in nr.items():assert norm(p)==norm(expected[name] if name in expected else old[name]),name
assert len(new['coordinates'])==521 and len(nr)==490
poly={}
for p in nr.values():poly=pa(poly,pm(p,p))
stored=json.loads((CANDIDATE.parent/'candidate-521-polynomial.json').read_text())
assert poly==read(stored['terms'])
assert len({m for s,m in poly})==34467

# Exact scalar block match into the 505 system, by semantic coordinate names.
cnames={c['name']:c['id'] for c in comb['coordinates']}
translation={c['id']:cnames[c['name']] for c in src['coordinates'] if c['name'] in cnames}
cr={r['name']:read(r['terms']) for r in comb['residuals']}
scalar_names=[r['name'] for r in src['residuals'] if r['name'].startswith(('scalar.shiftedS.','Sscalar.f.','Sscalar.z.'))]
scaled_id=next(c['id'] for c in src['coordinates'] if c['name']=='scalar.shiftedS.yProduct.1.quadratic')
for r in src['residuals']:
    if r['name'] in scalar_names:
        ts=[dict(t,coefficient=str(Q(t['coefficient'])*2**t['monomial'].count(scaled_id))) for t in r['terms']]
        assert norm(read(ts,translation))==norm(cr[r['name']]),r['name']
anchor=cr['anchor.translatedEquation']; f1=cnames['Sscalar.f.1']
assert anchor[(0,(f1,f1))]==-3 and comb['fixedParameter']['value']=='3^(2^25)'
P504=COMBINED.parent/'candidate504-ir.json'
d504=json.loads(P504.read_text());r504={r['name']:read(r['terms']) for r in d504['residuals']}
n504={c['name']:c['id'] for c in d504['coordinates']}
map504={i:n504[name] for name,i in names.items() if name in n504}
expect504={name:{(s,tuple(sorted(map504[i] for i in m))):v for (s,m),v in p.items()} for name,p in expected.items() if name.startswith(('scalar.shiftedS.','Sscalar.f.','Sscalar.z.'))}
removed504={name for name in removed if name.startswith('scalar.shiftedS.')}
assert set(r504)==(set(cr)-removed504)|set(expect504)
for name,p in r504.items():assert norm(p)==norm(expect504[name] if name in expect504 else cr[name]),name
assert len(d504['coordinates'])==504 and len(r504)==473
p504={}
for p in r504.values():p504=pa(p504,pm(p,p))
assert p504==read(json.loads((COMBINED.parent/'polynomial504.json').read_text())['terms'])
assert len({m for s,m in p504})==24733
report={'genericPolynomialIdentities':{name:'zero' for name in identities},'reconstructedChangedRows':len(expected),'unchangedRowsChecked':len(nr)-len(expected),'candidate521PolynomialTermsMatch':True,'candidate521Monomials':34467,'scalarRowsTransportedTo505':len(scalar_names),'scalarTransportScale':'old yProduct.1 = 2 * combined yProduct.1','newScalarSaving':1,'candidate504Variables':504,'candidate504Residuals':473,'candidate504Monomials':24733,'candidate504ChangedRowsVerified':len(expect504),'candidate504FullPolynomialMatch':True,'bindings':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [SOURCE,CANDIDATE,COMBINED,P504]}}
(HERE/'review-reciprocal-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
