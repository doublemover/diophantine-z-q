"""Build the order-10 source with agent07's six-coordinate toric chain."""
from pathlib import Path
import subprocess,sys,shutil,json
H=Path(__file__).resolve().parent;D=H.parent
s=(D/'beta12/build_source.cjs').read_text()
def edit(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
edit('order:i===1?12:40','order:i===1?10:40')
edit('tests.push({value:fsub(L[1],[beta,zero]),order:12}', 'tests.push({value:fsub(L[1],[beta,zero]),order:10}')
edit('for(let m of [1,12,40])coeffs[m]', 'for(let m of [1,10,40])coeffs[m]')
edit("evalSym('detector'+r+'.E12',coeffs[12],q12)", "evalSym('detector'+r+'.E10',coeffs[10],q10)")
a=s.index(" let em1=rquot('detector'+r+'.eMinus1'")
b=s.index(' let w=fmul(',a)
s=s[:a]+''' let q5=rp('detector'+r+'.qPower5',q1,5);
 let ta=rquot('detector'+r+'.toricA',q1,ep,'weight_nonzero');
 let tb=rquot('detector'+r+'.toricB',sq(ta),ep,'weight_nonzero');
 let tc=rquot('detector'+r+'.toricC',sq(tb),q1,'order_one_weight_nonzero');
 let td=rquot('detector'+r+'.toricD',q5,tc,'toric_C_nonzero');
 let q10=rquot('detector'+r+'.q10',sq(td),tc,'toric_C_nonzero');
 let q10sq=rsq('detector'+r+'.q10square',q10);
 let q40=rquot('detector'+r+'.q40',sq(q10sq),tc,'toric_C_nonzero');
'''+s[b:]
assert "log('logV'+i,p,i===1?12:40)" in s
out=H/'source10';out.mkdir(exist_ok=True)
(out/'build_source.cjs').write_text(s)
shutil.copytree(D/'beta12/sources',out/'sources',dirs_exist_ok=True)
with (out/'builder.log').open('w') as f:subprocess.run(['node',str(out/'build_source.cjs')],check=True,stdout=f)
with (out/'compiler.log').open('w') as f:subprocess.run([sys.executable,str(D/'compile_ir.py'),str(out/'raw-translated-ir.json'),str(out/'compiled')],check=True,stdout=f)
with (out/'checker.log').open('w') as f:subprocess.run(['node',str(D/'checker.cjs'),'--input',str(out/'raw-translated-ir.json'),'--compiled',str(out/'compiled/compiled-ir.json'),'--certificate',str(out/'compiled/reduction-certificate.json'),'--coordinate-map',str(out/'compiled/coordinate-map.json'),'--quartic',str(out/'compiled/polynomial.json'),'--report',str(out/'independent-check.json')],check=True,stdout=f)
old=json.loads((D/'beta12/raw-translated-ir.json').read_text())
new=json.loads((out/'raw-translated-ir.json').read_text())
blocks={'parameters_and_logarithms','direct_tests_and_shared_symmetric_coefficients'}
before={r['name'].replace('symmetric.12.','symmetric.10.').replace('testSquare.12.','testSquare.10.'):r['terms'] for r in old['residuals'] if r['block'] in blocks}
after={r['name']:r['terms'] for r in new['residuals'] if r['block'] in blocks}
assert before==after
compiled=json.loads((out/'compiled/compiled-ir.json').read_text())
oldcompiled=json.loads((D/'beta12/compiled/compiled-ir.json').read_text())
assert len(compiled['coordinates'])==len(oldcompiled['coordinates'])-6
print('All logarithm/test/grouped-coefficient residuals unchanged modulo order-group names; six compiled coordinates saved.')
print(json.loads((out/'compiled/compiler-report.json').read_text())['final'])
