# Ten independent Astra optimization approaches

Requested 7 November 2026. Baseline: 523 total variables, 522 witnesses, degree four, 35,163 monomials. The source is the 523/540 package in `work/quartic-version6-release/repository`. The Version 11 manuscript changes only the Kato explanation and source locator; its polynomial data are unchanged.

All ten tasks were launched with model `gpt-6-astra`, high reasoning effort, independent context and isolated working directories. The native limit is eight simultaneously active agents including the root, so launches occurred in waves. A completed task is not an active worker. Files and verdicts below are research candidates, not release acceptance.

| Task | Directory | Scope |
| --- | --- | --- |
| 1 | `01-elimination` | Exact elimination, affine changes and bounded ideal reduction |
| 2 | `02-squares` | Quadratic residuals, gate sharing and scaled detector poles |
| 3 | `03-depth` | Formal-log truncation, asymmetric precision and height bounds |
| 4 | `04-charts` | Elliptic charts and rational guards |
| 5 | `05-anchor` | Anchor coordinates, constants and power chains |
| 6 | `06-product` | Odd-product, norm-tree and scalar-leaf compression |
| 7 | `07-toric` | Laurent exponents and exact multiplication chains |
| 8 | `08-denominators` | Reciprocal charts, inverses and exceptional cases |
| 9 | `09-traceforms` | Field trace/norm and quadratic-form encodings |
| 10 | `10-combination` | Independent comparison and compatible composition |

Each task must retain exact source pins, an explicit forward/reverse argument and executable finite checks. A smaller coordinate count is not proof of the defining property. Arithmetic changes need the same source/convention/consumer review as the original construction.

Follow-up independent checks were assigned to task 1 for the combined finite transformation, task 3 for task 5's anchor argument, and task 4 for task 6's scalar argument. No worker is assigned independent acceptance of its own contribution. Task 10 records incompatible transformations rather than adding their advertised savings blindly.

The research folder is not part of the Version 11 release. Its candidates must pass the revised application-review protocol before a new manuscript or public-record claim is made.
