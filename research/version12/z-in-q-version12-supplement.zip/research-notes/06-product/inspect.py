import json
from pathlib import Path
p=Path('work/quartic-version6-release/repository/quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json')
d=json.loads(p.read_text())
cs={c['id']:c['name'] for c in d['coordinates']}
for c in d['coordinates']:
 if c['block']=='scalar_block': print(c['id'],c['name'])
for r in d['residuals']:
 if r['block']=='scalar_block':
  print('ROW',r['id'],r['name'], ' '.join(t['coefficient']+'*'+'*'.join(cs[i] for i in t['monomial']) for t in r['terms']))
