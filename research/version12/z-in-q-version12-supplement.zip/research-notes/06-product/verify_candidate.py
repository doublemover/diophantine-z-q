"""Independent residual-change check; no candidate builder or compiler imported."""
import hashlib,json
from pathlib import Path
from fractions import Fraction as F
HERE=Path(__file__).resolve().parent
BASE=HERE.parent.parent/'quartic-version6-release/repository/quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json'
def read(ts):
 out={}
 for t in ts:
  k=(t.get('sPower',0),tuple(t['monomial']));out[k]=out.get(k,F(0))+F(t['coefficient'])
 return {k:v for k,v in out.items() if v}
def add(*ps):
 out={}
 for p in ps:
  for k,v in p.items():out[k]=out.get(k,F(0))+v
 return {k:v for k,v in out.items() if v}
def scale(p,k):return {m:v*k for m,v in p.items() if v*k}
def mul(p,q):
 out={}
 for (s,m),v in p.items():
  for (t,n),w in q.items():
   k=(s+t,tuple(sorted(m+n)));out[k]=out.get(k,F(0))+v*w
 return {k:v for k,v in out.items() if v}
def sub(p,q):return add(p,scale(q,-1))
def v(i):return {(0,(i,)):F(1)}
one={(0,()):F(1)}
a=json.loads(BASE.read_text());b=json.loads((HERE/'candidate518-ir.json').read_text())
assert hashlib.sha256(BASE.read_bytes()).hexdigest()==b['variant']['baselineSha256']
ar={r['id']:read(r['terms']) for r in a['residuals']};br={r['id']:read(r['terms']) for r in b['residuals']}
assert len(br)==len(b['residuals'])==487
assert set(ar)-set(br)==set(range(481,494))
assert set(br)-set(ar)==set(range(608,616))
assert all(ar[k]==br[k] for k in ar.keys()&br.keys() if k!=495)
ac={c['id'] for c in a['coordinates']};bc={c['id'] for c in b['coordinates']}
assert len(bc)==len(b['coordinates'])==518
assert ac-bc==set(range(515,528)) and bc-ac==set(range(540,548))
assert all(len(m)<=2 for p in br.values() for s,m in p)
assert {i for p in br.values() for s,m in p for i in m}==bc
value=lambda name:read(a['values'][name]['terms'])
r=value('scalar.r');f0=value('U0.f.0');f1=value('U0.f.1')
z0=value('scalar.zRatio.0');z1=value('scalar.zRatio.1')
q,A,U,V,V2,B,B2,W=map(v,range(540,548))
expected=[sub(q,sub(mul(f0,f0),scale(mul(f1,f1),2))),sub(mul(r,sub(A,one)),mul(q,q)),sub(U,mul(z0,v(499))),sub(V,mul(z1,v(499))),sub(V2,mul(V,V)),sub(B,add(mul(U,U),mul(r,V2))),sub(B2,mul(B,B)),sub(W,add(mul(A,A),mul(r,B2)))]
assert all(br[i]==p for i,p in zip(range(608,616),expected))
assert br[495]==sub(value('scalar.W2'),mul(W,W))
# Duplication formula numerator, with formal indeterminates x and D.
x,D=v(0),v(1);x2=mul(x,x)
assert sub(sub(mul(sub(scale(x2,3),D),sub(scale(x2,3),D)),scale(mul(x2,sub(x2,D)),8)),mul(add(x2,D),add(x2,D)))=={}
# Exhaust finite valuations to check the strict bounds used in the proof.
checks=0
for rho in range(1,40,2):
 for aq in range(-2*rho,2*rho+1):
  for u in range(-2*rho,2*rho+1):
   for vv in range(-2*rho,2*rho+1):
    av=min(0,rho+2*aq);bv=min(2*u,rho+2*vv);wv=min(2*av,rho+2*bv)
    if rho+2*wv>0:
     assert rho+aq>=1 and 32*rho+u>=32 and 32*rho+vv>=32
    checks+=1
result={'status':'passed','coordinates':518,'witnesses':517,'residuals':487,'newRows':8,'removedRows':13,'replacedRows':1,'maxResidualDegree':2,'duplicationNumeratorIdentity':True,'finiteValuationChecks':checks,'arithmeticProof':'REPORT.md; requires independent review','candidateSha256':hashlib.sha256((HERE/'candidate518-ir.json').read_bytes()).hexdigest()}
(HERE/'candidate-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
