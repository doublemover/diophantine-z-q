import json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
r={'approach':'06-product','result':'explicit candidate','baselineTotalVariables':523,'candidateTotalVariables':518,'savedVariables':5,'witnesses':517,'quadraticResiduals':487,'degree':4,'monomials':35031,'fixedParameter':'3^(2^26)','maximumAbsoluteCoefficient':'64 * S^2','content':1,'arithmeticStatus':'Proof supplied in REPORT.md; independent arithmetic review pending','exactChecks':'passed','files':{}}
for f in ['REPORT.md','candidate518-ir.json','polynomial/polynomial.json','independent-check.json','candidate-check.json']:
 r['files'][f]=hashlib.sha256((p/f).read_bytes()).hexdigest()
(p/'SUMMARY.json').write_text(json.dumps(r,indent=2)+'\n')
