from pathlib import Path
import re,json,hashlib
p=Path(__file__).resolve().parent
repo=p.parent.parent.parent/'quartic-version6-release/repository'
src=(repo/'manuscripts/quartic_v11.tex').read_text()
new=(p/'addition.tex').read_text()
oldlabels=set(re.findall(r'\\label\{([^}]+)\}',src)); labels=re.findall(r'\\label\{([^}]+)\}',new)
refs=set(re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',new))
assert len(labels)==len(set(labels));assert not set(labels)&oldlabels
assert refs<=oldlabels|set(labels),refs-oldlabels-set(labels)
pre=src.split(r'\begin{document}')[0]
(p/'syntax-check.tex').write_text(pre+'\n\\begin{document}\n'+new+'\n\\begin{thebibliography}{9}\n\\bibitem{silverman} J. H. Silverman, The Arithmetic of Elliptic Curves, second edition, 2009.\n\\bibitem{voight2021} J. Voight, Quaternion Algebras, source version recorded in APPLICATIONS.json.\n\\end{thebibliography}\n\\end{document}\n')
(p/'reference-check.json').write_text(json.dumps({'newLabels':labels,'inheritedReferences':sorted(refs-set(labels)),'unresolved':[]},indent=2))
print(len(labels),'new labels;',len(refs),'references checked')
