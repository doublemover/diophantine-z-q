from pathlib import Path
p=Path('addition.tex');s=p.read_text()
s=s.replace(r'\cite[Proposition 14.6.7]{voight2021}',r'\cite[Proposition 14.6.7, pp.~223--224]{voight-quaternion}')
s=s.replace('table uses the fixed integer $C=3^{2^{25}}$, not an additional variable.\n\\end{theorem}', '''table uses the fixed integer $C=3^{2^{25}}$, not an additional variable.
There is also a specified integer quartic $P_{514}$ with
\\[
 X\\in\\Z\\quad\\Longleftrightarrow\\quad
 \\exists\\mathbf w\\in\\Q^{513}:P_{514}(X,\\mathbf w)=0.
\\]
It has 24,716 nonzero monomials, content one, and largest absolute
coefficient $3^{2048}+1005072314676622<2^{3247}$.
\\end{theorem}''')
s=s.replace('projection and 513 existential witnesses.  The lift is unique, so it\nrequires no additional arithmetic argument.', '''projection and 513 existential witnesses.  It has 483 quadratic
residuals and 24,716 monomials, with content one and maximum coefficient
$3^{2048}+1005072314676622<2^{3247}$.  Its coefficient table,
\\texttt{polynomial514.json}, has SHA-256
\\begin{center}\\small
\\nolinkurl{d247a27709afda5f2be626390cffa1a175c3dfcbee1a5c832a1c457b32629bd5}.
\\end{center}
The lift is unique, so it requires no additional arithmetic argument.''')
p.write_text(s)
