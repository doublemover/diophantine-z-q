"""Rebuild and check an exact 498-coordinate toric replacement of current523."""
from pathlib import Path
from fractions import Fraction
from math import lcm, gcd
from collections import defaultdict
import json, hashlib

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent.parent/'10-combination/candidate501-ir.json'
raw=SOURCE.read_bytes(); old=json.loads(raw)
coords=old['coordinates']; residuals=old['residuals']
assert len(coords)==501
names={c['name']:c['id'] for c in coords}
def find(prefix):
    matches=[(n,i) for n,i in names.items() if n==prefix or n==prefix+'.quadratic']
    assert len(matches)==1, (prefix,matches)
    return matches[0][1]
def termpoly(r):
    return {(tuple(t['monomial']),t['sPower']):Fraction(t['coefficient']) for t in r['terms']}
def poly(*terms):
    return {(tuple(sorted(mon)),0):Fraction(c) for c,mon in terms}
def up_to_sign(a,b):return a==b or a=={k:-v for k,v in b.items()}
def normalize(p):
    den=lcm(*(c.denominator for c in p.values()))
    content=0
    for c in p.values():content=gcd(content,int(c*den))
    factor=Fraction(den,content)
    if p[min(p,key=lambda k:(k[1],k[0]))]<0:factor=-factor
    return {k:c*factor for k,c in p.items()}
assert hashlib.sha256(raw).hexdigest()=='6a31040f85e30cc6f9d076bf6c92218be110e0829e93333d7e99f93a6b2f0d9a'
remove_ids=set(); remove_names=set(); additions=[]; rename={}; certificates=[]
for d in range(3):
    p=f'detector{d}.'
    E=find(p+'eWeight'); q=find(p+'q1'); out=find(p+'q40')
    a,b,c,h,u=[find(p+'toric.'+s) for s in ['a','b','u','v','t']]
    bridge=find(p+'q12');q2=find(p+'E1.power2');q3=find(p+'E1.power3')
    q5=find(p+'E1.power5');R=find(p+'E12.power2')
    oldsuffix=['a','b','u','v','q12','t','q40']
    expected=[poly((1,[E,a]),(-1,[])),poly((1,[E,b]),(-1,[a,a])),
      poly((1,[b,c]),(-1,[E,q])),poly((1,[b,h]),(-1,[c,c])),
      poly((1,[q3,bridge]),(-1,[h,h])),poly((1,[q,u]),(-1,[E,R])),
      poly((1,[h,out]),(-1,[R,u]))]
    for suffix,expect in zip(oldsuffix,expected):
        n=p+'toric.'+suffix+'.definition'
        rs=[r for r in residuals if r['name']==n]
        assert len(rs)==1 and up_to_sign(termpoly(rs[0]),expect),n
        remove_names.add(n)
    for suffix,expect in [('E1.power2',poly((1,[q,q]),(-1,[q2]))),
          ('E1.power3',poly((1,[q,q2]),(-1,[q3]))),
          ('E1.power5',poly((1,[q2,q3]),(-1,[q5]))),
          ('E12.power2',poly((1,[bridge,bridge]),(-1,[R])))]:
        rs=[r for r in residuals if r['name']==p+suffix+'.definition']
        assert len(rs)==1 and up_to_sign(termpoly(rs[0]),expect)
    internal={a,b,c,h,u}
    for r in residuals:
        if r['name'] not in remove_names:
            assert not any(internal.intersection(t['monomial']) for t in r['terms']),r['name']
    remove_ids.add(u)
    for i,n in zip([a,b,c,h],['a','b','c','d']):rename[i]=p+'order10.'+n
    rename[bridge]=p+'q10'
    new=[('a',poly((1,[E,a]),(-1,[q]))),('b',poly((1,[E,b]),(-1,[a,a]))),
      ('c',poly((1,[q,c]),(-1,[b,b]))),('d',poly((1,[c,h]),(-1,[q5]))),
      ('q10',poly((1,[c,bridge]),(-1,[h,h]))),('q40',poly((1,[c,out]),(-1,[R,R])))]
    exps={E:(1,0),q:(0,1),q5:(0,5),R:(36,2),a:(-1,1),b:(-3,2),c:(-6,3),
          h:(6,2),bridge:(18,1),out:(78,1)}
    for label,rpoly in new:
        sides=[]
        for (mon,sp),coef in rpoly.items():
            sides.append(tuple(sum(exps[i][j] for i in mon) for j in range(2)))
        assert sides[0]==sides[1]
        additions.append({'name':p+'toric.'+label+'.definition','kind':'toric-replacement',
            'terms':[{'monomial':list(mon),'sPower':sp,'coefficient':str(coef)} for (mon,sp),coef in rpoly.items()]})
    certificates.append({'detector':d,'old_internal':sorted(internal),'removed':u,
       'shared_q_cubed':q3,'exponents':{str(k):list(t) for k,t in exps.items()}})
newcoords=[dict(c,name=rename.get(c['id'],c['name']).replace('.E12.','.E10.')) for c in coords if c['id'] not in remove_ids]
mapping={c['id']:i for i,c in enumerate(newcoords)}
for c in newcoords:c['sourceId']=c['id'];c['id']=mapping[c['id']]
newres=[r.copy() for r in residuals if r['name'] not in remove_names]+additions
for j,r in enumerate(newres):
    r['id']=j
    r['name']=r['name'].replace('.E12.','.E10.')
    pnorm=normalize(termpoly(r))
    r['terms']=[{'monomial':sorted(mapping[i] for i in mon),'sPower':sp,
                     'coefficient':str(int(c))} for (mon,sp),c in pnorm.items()]
    assert max(len(t['monomial']) for t in r['terms'])<=2
assert len(newcoords)==498 and len(newres)==len(residuals)-3
P=defaultdict(int)
for r in newres:
    ts=r['terms']
    for j,t in enumerate(ts):
        for u in ts[j:]:
            key=(tuple(sorted(t['monomial']+u['monomial'])),t['sPower']+u['sPower'])
            P[key]+=(1 if u is t else 2)*int(t['coefficient'])*int(u['coefficient'])
P={k:v for k,v in P.items() if v}
degree=max(len(k[0]) for k in P); assert degree==4
monomials=len({k[0] for k in P})
content=0
for v in P.values():content=gcd(content,v)
assert any(abs(v)==1 and sp==0 and all(m2!=mon or sp2==0 for m2,sp2 in P)
           for (mon,sp),v in P.items())
candidate={'schema':'order10-toric-quadratic-ir-v1', 'status':'research candidate; precision change requires arithmetic argument in 03-depth/lower-precision/ARITHMETIC.md','source_sha256':hashlib.sha256(raw).hexdigest(),
 'fixedParameter':old['fixedParameter'],'coordinates':newcoords,'residuals':newres}
(HERE/'candidate498.json').write_text(json.dumps(candidate,indent=2)+'\n')
(HERE/'polynomial498.json').write_text(json.dumps({'schema':'symbolic-sum-of-squares-v1',
 'fixedParameter':old['fixedParameter'],'terms':[{'monomial':list(m),'sPower':s,'coefficient':str(c)}
 for (m,s),c in sorted(P.items())]},indent=2)+'\n')
report={'source_sha256':hashlib.sha256(raw).hexdigest(),'source_coordinates':len(coords),
 'source_residuals':len(residuals),'coordinates':len(newcoords),'witnesses':len(newcoords)-1,
 'residuals':len(newres),'degree':degree,'monomials':monomials,'symbolic_terms':len(P),
 'integer_content_before_S_specialization':content,'certificates':certificates}
(HERE/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='certificates'},indent=2))
