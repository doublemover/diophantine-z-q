from itertools import combinations_with_replacement
from time import monotonic
START=monotonic(); count=[0]*8; solution=None
BASE=[(0,0),(1,0)]+[(0,i) for i in range(1,6)]
def options(vals):
 out={}
 for a,b in combinations_with_replacement(range(len(vals)),2):
  for c in range(len(vals)):
   v=(vals[a][0]+vals[b][0]-vals[c][0],vals[a][1]+vals[b][1]-vals[c][1])
   if v not in vals:out.setdefault(v,(a,b,c))
 return out
def finish(vals,ops,remain):
 global solution
 count[7-remain]+=1
 opts=options(vals)
 if (78,1) in opts:
  solution=(vals+[(78,1)],ops+[opts[(78,1)]]);return True
 if remain==1:return False
 for v,op in opts.items():
  if finish(vals+[v],ops+[op],remain-1):return True
 return False
def dfs(vals,ops,remain):
 count[5-remain]+=1
 lo=min(v[0] for v in vals);hi=max(v[0] for v in vals)
 if (hi-lo)*2**remain<20:return False
 for v,op in options(vals).items():
  x,y=v
  if not(x<lo or x>hi):continue
  if x>20:continue
  if (max(hi,x)-min(lo,x))*2**(remain-1)<20:continue
  if remain==1:
   if v!=(20,1):continue
   if finish(vals+[v,(40,2)],ops+[op,('free_square',len(vals))],1):return True
  elif dfs(vals+[v],ops+[op],remain-1):return True
 return False
print(dfs(BASE,[],5),solution,count,monotonic()-START,flush=True)
