"""Assemble portable frozen inputs and replay tools, without altering any candidate."""
from pathlib import Path
import json,hashlib,shutil
H=Path(__file__).resolve().parent;W=H.parent;REPO=W.parent/'quartic-version6-release/repository';OUT=H/'release498'
OUT.mkdir(exist_ok=True);work=OUT/'work';scripts=work/'10-combination';scripts.mkdir(parents=True,exist_ok=True)
origins={}
def cp(src,dst,origin):
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);origins[str(dst.relative_to(OUT)).replace('\\','/')]=origin
for folder,names in {
 '02-squares':['candidate520-ir.json','REPORT.md','normalization-certificate.json'],
 '03-depth':['REPORT.md','experiment.py','checker.cjs','compile_ir.py'],
 '04-charts':['candidate-518.json','REPORT.md'],
 '05-anchor':['candidate522-smallcoeff-ir.json','REPORT.md','review-reciprocal.md'],
 '06-product':['candidate518-ir.json','REPORT.md'],
 '07-toric/mixed':['candidate516.json','RESULT.md','report.json'],
 '08-denominators':['candidate-521-ir.json','REPORT.md','check_reciprocal.py'],
 '04-charts/further-scalar-cancel':['candidate502-ir.json','certificate502.json','REPORT.md'],
 '01-elimination/sub500/from501':['elimination500-certificate.json'],
}.items():
 for name in names:cp(W/folder/name,work/folder/name,{'optimizerSource':folder+'/'+name})
for src in (W/'03-depth/beta12').rglob('*'):
 if src.is_file() and src.suffix not in ['.log']:
  rel=src.relative_to(W);cp(src,work/rel,{'optimizerSource':str(rel).replace('\\','/')})
for name in ['candidate498-ir.json','polynomial498.json','candidate514-ir.json','polynomial514.json']:
 cp(H/name,OUT/name,{'frozenSource':'10-combination/'+name})
for name in ['REPORT.md','REPORT504.md','REPORT501.md','REPORT498.md']:
 cp(H/name,OUT/'proofs'/name,{'optimizerSource':'10-combination/'+name})
script_names=['build.py','depth_recheck.py','verify.py','build504.py','verify504.py','build501.py','verify501.py','build499.py','verify499.py','build498.py','verify498.py','ordinary514.py']
replacements={
 "R=W.parent/'quartic-version6-release/repository'":"R=reference_repo()",
 "R=H.parents[1]/'quartic-version6-release/repository'":"R=reference_repo()",
 "REPO=ROOT.parents[1]/'quartic-version6-release'/'repository'":"REPO=reference_repo()",
}
for name in script_names:
 text=(H/name).read_text()
 for old,new in replacements.items():text=text.replace(old,new)
 text='from package_paths import reference_repo\n'+text
 dst=scripts/name;dst.write_text(text);origins[str(dst.relative_to(OUT)).replace('\\','/')]={'adaptedFrom':'10-combination/'+name,'adaptation':'Only reference-repository path discovery; computational code unchanged.'}
(scripts/'package_paths.py').write_text('''from pathlib import Path
import os
def reference_repo():
    explicit=os.environ.get('QUARTIC_REFERENCE_REPO')
    candidates=[Path(explicit)] if explicit else list(Path(__file__).resolve().parents)
    for root in candidates:
        if (root/'quartics/quartic-523-540/final523_540/verify_elimination.py').is_file():return root
    raise RuntimeError('Supply --repo PATH to the repository containing quartics/quartic-523-540.')
''')
repo_files=[
 'quartics/quartic-523-540/final523_540/verify_elimination.py',
 'quartics/quartic-523-540/final523_540/verify_all.py',
 'quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json',
 'quartics/quartic-523-540/final523_540/symbolic523/integer-candidate-ir.json',
 'quartics/quartic-523-540/source-reproduction/builders/odd-product-asymmetric-source.cjs',
 'quartics/quartic-523-540/source-reproduction/tools/checker.cjs',
 'quartics/quartic-523-540/source-reproduction/tools/compile_ir.py',
 'quartics/quartic-523-540/source-reproduction/sources/diophantine_optimization_20261106_v3.tex',
]
def pin(p):return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
(OUT/'repository-pins.json').write_text(json.dumps([dict(path=p,**pin(REPO/p)) for p in repo_files],indent=2)+'\n')
(OUT/'input-origins.json').write_text(json.dumps(origins,indent=2,sort_keys=True)+'\n')
print('Portable inputs and scripts assembled:',OUT)
