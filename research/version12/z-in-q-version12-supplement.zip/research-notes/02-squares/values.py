from search import *
d=json.loads(SRC.read_text())
for k in range(3):
 for s in ['W.0','W.1','normOver2w0']:
  name='detector'+str(k)+'.'+s;print(name,d['values'].get(name))
