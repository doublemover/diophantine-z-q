import json,hashlib,copy,math,functools
from pathlib import Path
from search import *
d=json.loads(SRC.read_text());rows={r['id']:read(r['terms']) for r in d['residuals']}; byname={c['name']:c['id'] for c in d['coordinates']}; rname={r['name']:r['id'] for r in d['residuals']}
removed=[]; ops=[]
for k in range(3):
 pre='detector'+str(k)
 ids={n:byname[pre+'.'+n] for n in ['B','scaled_e','p','s','q','p2.quadratic','s2.quadratic','q2.quadratic','U2.quadratic','Bh.quadratic']}
 b,e,p,s,q,p2,s2,q2,u2,f=[ids[n] for n in ['B','scaled_e','p','s','q','p2.quadratic','s2.quadratic','q2.quadratic','U2.quadratic','Bh.quadratic']]
 replacements={
 'p2.definition':{(0,(p,p)):Q(1),(0,(p2,)):Q(-1)},
 's2.definition':{(0,(s,s)):Q(1),(0,(s2,)):Q(-1)},
 'q2.definition':{(0,(q,q)):Q(1),(0,(q2,)):Q(-1)},
 'firstConic':{(0,tuple(sorted((b,p2)))):Q(17),(0,(e,e)):Q(3),(0,(e,)):Q(-34),(0,()):Q(-289)},
 'Bh.definition':{(0,(e,)):Q(17),(0,tuple(sorted((e,b)))):Q(-1),(0,(f,)):Q(-17)},
 'secondConic':{(0,tuple(sorted((b,q2)))):Q(17),(0,(f,f)):Q(867),(0,tuple(sorted((f,s2)))):Q(-34),(0,(s2,s2)):Q(-1)}}
 for name,pol in replacements.items():rows[rname[pre+'.'+name]]=pol
 del rows[rname[pre+'.U2.definition']];removed.append(u2)
 ops.append({'detector':k,'ids':ids,'droppedRow':rname[pre+'.U2.definition'],'updatedRows':[rname[pre+'.'+n] for n in replacements]})
coords=[]
for c in d['coordinates']:
 if c['id'] in removed:continue
 c=copy.deepcopy(c)
 for op in ops:
  for n,i in op['ids'].items():
   if c['id']==i and n!='B':c['name']='detector'+str(op['detector'])+'.normalized.'+n
 coords.append(c)
new={'format':'quadratic-residual-system-v1','fixedParameter':d['fixedParameter'],'coordinates':coords,'residuals':[dict(r,terms=encode(rows[r['id']])) for r in d['residuals'] if r['id'] in rows], 'note':'Candidate pending independent review. Rationally equivalent to pinned baseline by nonzero-b pole normalization.'}
(BASE/'candidate520-ir.json').write_text(json.dumps(new,indent=2)+'\n')
cert={'baselinePath':str(SRC),'baselineSha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'operations':ops,'removedCoordinates':removed,'candidateSha256':hashlib.sha256((BASE/'candidate520-ir.json').read_bytes()).hexdigest()}
(BASE/'normalization-certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
# Normalize each residual to a primitive integer polynomial, preserving its zero set.
integer={}
for ri,p in rows.items():
 den=functools.reduce(math.lcm,(c.denominator for c in p.values()),1)
 num=functools.reduce(math.gcd,(abs(c.numerator*(den//c.denominator)) for c in p.values()),0)
 integer[ri]={m:c*Q(den,num) for m,c in p.items()}
poly={}
for p in integer.values():poly=add(poly,mul(p,p))
active=sorted({x for p in integer.values() for x in vs(p)});assert active==sorted(c['id'] for c in coords)
mp={x:i for i,x in enumerate(active)}
table={'schema':'brox-sparse-polynomial-v1','fixedParameter':'S = 3^(2^26)','coordinates':[dict(c,id=mp[c['id']],sourceId=c['id']) for c in coords], 'terms':encode({(s,tuple(mp[i] for i in m)):v for (s,m),v in poly.items()})}
(BASE/'polynomial520.json').write_text(json.dumps(table,separators=(',',':'))+'\n')
summary={'status':'pending independent review','variables':len(coords),'witnesses':len(coords)-1,'residuals':len(rows),'degree':degree(poly),'monomials':len({m for s,m in poly}),'coefficientTerms':len(poly),'content':functools.reduce(math.gcd,(abs(v.numerator) for (s,m),v in poly.items() if s==0),0),'fixedParameter':'S = 3^(2^26)','largestSFreeCoefficient':str(max(abs(v.numerator) for (s,m),v in poly.items() if s==0)),'sTerms':encode({k:v for k,v in poly.items() if k[0]}),'polynomialSha256':hashlib.sha256((BASE/'polynomial520.json').read_bytes()).hexdigest()}
(BASE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
