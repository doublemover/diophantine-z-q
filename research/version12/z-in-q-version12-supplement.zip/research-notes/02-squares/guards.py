import json
from pathlib import Path
p=Path('work/quartic-version6-release/repository/quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json')
d=json.loads(p.read_text())
for r in d['residuals']:
 if any(r['name']=='detector'+str(k)+'.'+t for k in range(3) for t in ['w0Inverse.definition','normOver2w0.definition','B.definition']):print(r['id'],r['name'],r['terms'])
