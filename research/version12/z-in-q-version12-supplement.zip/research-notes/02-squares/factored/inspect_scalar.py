import json
from pathlib import Path
h=Path(__file__).resolve().parent;d=json.loads((h.parents[1]/'10-combination/candidate501-ir.json').read_text());cs={c['id']:c for c in d['coordinates']}
for r in d['residuals']:
 if r['name'].startswith('scalar.') and any(t in r['name'] for t in ['.Bh.','.s2.','.q2.','secondConic']):
  print(r);print([cs[v]['name'] for v in sorted({v for t in r['terms'] for v in t['monomial']})])
