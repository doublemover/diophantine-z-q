"""Read-only verification of scalar factorization, following verified detector factorization."""
from pathlib import Path
import json,hashlib,math,functools
from fractions import Fraction as F
import verify as V
H=Path(__file__).resolve().parent

def main():
 V.main()
 cert=V.read(H/'certificate497.json');source=Path(cert['source'])
 assert V.sha(source)==cert['sourceSha256']
 assert V.sha(H/'candidate497-ir.json')==cert['candidateSha256']
 assert V.sha(H/'polynomial497.json')==cert['polynomialSha256']
 old=V.read(source);new=V.read(H/'candidate497-ir.json')
 before={r['id']:V.poly(r['terms']) for r in old['residuals']};after={r['id']:V.poly(r['terms']) for r in new['residuals']}
 b,t,t2,q,q2,f=[cert['ids'][x] for x in ['b','t','t2','q','q2','f']]
 rb,rq,rt,rc=[cert['rows'][x] for x in ['Bh','q2','s2','secondConic']]
 names={c['name']:c['id'] for c in old['coordinates']};rn={r['name']:r['id'] for r in old['residuals']}
 assert [b,t,t2,q,q2,f]==[names[x] for x in ['scalar.b.quadratic','scalar.s','scalar.s2.quadratic','scalar.q','scalar.q2.quadratic','scalar.Bh.quadratic']]
 assert [rb,rq,rt,rc]==[rn[x] for x in ['scalar.Bh.definition','scalar.q2.definition','scalar.s2.definition','scalar.secondConic']]
 mp={f:V.mon(t,f),q:V.mon(t,q),q2:V.mon(t,t,q2),t2:V.mon(t,t)}
 assert set(after)==set(before)-{rt}
 for r,p in before.items():
  expected={} if r==rt else V.mul(V.mon(t,t) if r in [rq,rc] else V.mon(),after[r])
  assert V.sub(p,mp)==expected,r
 # Source scalar coordinate b has a negative normalization. Do not assume b>0.
 # Read the actual semantic scale and certify the t=0 equation as a negative
 # sum of two nonnegative terms when semantic pole input B is positive.
 semantic_source=Path(cert['semanticSource'])
 assert V.sha(semantic_source)==cert['semanticSourceSha256']
 depth=V.read(semantic_source)
 semanticB=V.poly(depth['values']['scalar.b']['terms']);semanticH=V.poly(depth['values']['scalar.Bh']['terms'])
 assert set(semanticB)=={(b,)} and set(semanticH)=={(f,)}
 K=-semanticB[(b,)];assert K>0 and semanticH[(f,)]==-17*K
 branch=V.sub(before[rc],{t:{},t2:{},q2:V.mon(q,q)})
 # Exact normalization: the source residual is -17 B q^2 - 3 H^2 at t=0.
 expected=V.add({m:-17*c for m,c in V.mul(semanticB,V.mon(q,q)).items()},V.mul(semanticH,semanticH),-3)
 assert branch==expected
 assert before[rt]==V.add(V.mon(t,t),V.mon(t2),-1)
 assert before[rq]==V.add(V.mon(q,q),V.mon(q2),-1)
 lift={t:{},q:{},q2:{},f:{}}
 assert V.sub(after[rq],lift)=={} and V.sub(after[rc],lift)=={}
 assert V.sub(after[rb],lift)==V.sub(before[rb],{f:{}})
 oldids={c['id'] for c in old['coordinates']};newids={c['id'] for c in new['coordinates']}
 assert newids==oldids-{t2} and len(newids)==497
 assert old['fixedParameter']==new['fixedParameter']
 assert old['coordinates'][0]==new['coordinates'][0]
 assert {v for p in after.values() for m in p for v in m if v!=-1}==newids
 assert all(sum(v!=-1 for v in m)<=2 for p in after.values() for m in p)
 total={}
 for p in after.values():
  items=list(V.norm(p).items())
  for i,(m,c) in enumerate(items):
   for j in range(i,len(items)):
    n,d=items[j];z=tuple(sorted(m+n));total[z]=total.get(z,F(0))+c*d*(1 if i==j else 2)
 total={m:c for m,c in total.items() if c}
 assert total==V.poly(V.read(H/'polynomial497.json')['terms'])
 assert max(sum(v!=-1 for v in m) for m in total)==4
 assert functools.reduce(math.gcd,(abs(c.numerator) for m,c in total.items() if -1 not in m),0)==1
 assert {m:c for m,c in total.items() if m.count(-1)==2}=={(-1,-1,57,57):F(16)}
 assert (57,57) not in total and (-1,57,57) not in total
 assert max(abs(c) for m,c in total.items() if m.count(-1)==1)<=48
 assert max(abs(c.numerator).bit_length() for m,c in total.items() if -1 not in m)<2048
 assert len(after)==466 and len({tuple(v for v in m if v!=-1) for m in total})==24708
 print(json.dumps({'verified':True,'variables':497,'witnesses':496,'residuals':466,'degree':4,'monomials':24708,'content':1,'largestCoefficient':'16 * 3^(2^26)','semanticScalarB':'-K times stored b, K>0','sourceSha256':V.sha(source),'candidateSha256':V.sha(H/'candidate497-ir.json'),'polynomialSha256':V.sha(H/'polynomial497.json'),'independentReview':'pending'},indent=2))
if __name__=='__main__':main()
