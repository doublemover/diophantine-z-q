import json
from pathlib import Path
h=Path(__file__).resolve().parent;d=json.loads((h.parents[1]/'03-depth/beta12/final/candidate-ir.json').read_text())
for n in ['scalar.b','scalar.Bh','scalar.U2','scalar.s2','scalar.q2']:
 print(n,d['values'].get(n))
