# Extension to 497 variables: factor the scalar second conic too

Status: candidate pending independent review. This extends the detector transformation in `REPORT.md` by applying the same operation to the scalar pole. It preserves the 498-variable artifacts as an intermediate stage.

The complete candidate has 497 variables including the input, 496 existential witnesses, 466 quadratic residuals, and 24,708 quartic monomials. It has content one and largest absolute coefficient `16*C^2`, where the fixed integer is `C=3^(2^25)`.

`candidate497-ir.json` has SHA-256

```
66658ffa210438eb6982455746182e695af664fc037cdb1f6c8daa1ce75dbd7e
```

`polynomial497.json` has SHA-256

```
69d21e4f620abd2d45a98ffc75cbcd9d1709e3cbb0a624777646369d14a7714f
```

The source is the pinned `candidate498-ir.json` described in `REPORT.md`, hash `0b72432400cb01cb1531a26ca370ee5988bd8b8d9537aaa8640a3e98f4cfabba`. The complete chain therefore starts with the 501-variable source pinned there and removes four coordinates, one from each of the three detector second conics and one from the scalar second conic.

## General scalar factorization

Use semantic scalar quantities for this paragraph. Write B for the actual scalar pole input, H for its Bh quantity, t for its s witness, and q for its q witness. Its second conic is

```
17B q^2 = (t^2-H)(t^2+3H).
```

The Bh definition contains H only linearly, with all other terms quadratic. Substitute

```
H = tV,
q = tQ.
```

After removing the common factor t^2, the conic is

```
17B Q^2 = t^2 + 2tV - 3V^2.
```

Retain one coordinate Q2=Q^2. Replace the old H coordinate by V and remove the old t2=t^2 coordinate. Substitution into the Bh definition remains quadratic. The preparation equations and first conic are unchanged. This saves one coordinate and one residual.

As in the detector proof, every new solution reconstructs an old one polynomially, including at t=0. For completeness, if t is nonzero divide H and q by t. If t=0, positive B makes the old equation `17B q^2 + 3H^2=0` force q=H=0. Choose V=Q=Q2=0. This supplies the exceptional branch without division.

## Exact normalization in the actual artifact

The compiler does not store B or H directly. In the pinned mixed-depth source, and in the scalar block retained by the 498-variable source,

```
B = -K * b,
H = -17K * f,
```

where b and f are the stored `scalar.b.quadratic` and `scalar.Bh.quadratic` coordinates, and K is the positive integer

```
80990493410131000784375977023646274345820490095244015289194989569855772668241364832628280392076492800000000000000.
```

In particular, positive B means the stored b coordinate is negative. Assuming that stored coordinate is positive would be incorrect.

The literal second-conic row is

```
17K*b*q2 - 867K^2*f^2 - 34K*f*t2 + t2^2 = 0.
```

Replace f=t*v, q=t*Q, q2=t^2*Q2, and t2=t^2. It becomes t^2 times

```
17K*b*Q2 - 867K^2*v^2 - 34K*t*v + t^2 = 0.
```

The actual Bh row has the form

```
17*e*b + K*e*u2 - 17*f = 0,
```

and becomes `17*e*b + K*e*u2 - 17*t*v = 0`. This is quadratic. The verifier checks the actual rows, their constants, and every unaffected row.

The removed scalar coordinate is 533, named `scalar.s2.quadratic`, and the removed defining residual is 500. The reused coordinates are 532 for v, 54 for Q, and 534 for Q2. The certificate records these identifiers and their source names.

At t=0, the literal old row after using q2=q^2 is exactly

```
-17*B*q^2 - 3*H^2.
```

The verifier checks this identity using the pinned source's semantic expressions, as well as K>0 and the displayed normalization. This is the expression to which the positivity argument applies.

## Positive scalar input in completeness

The same pinned Version 11 manuscript cited in `REPORT.md` supplies the required scalar positivity. Its completeness proof near lines 11345-11357 chooses the finite correction so that `c*r_beta>0`, arranges the norm-tree value to be a nonzero unit at the required places, and sets `b_beta=c*r_beta*W_beta^2`. Thus its actual scalar pole input is strictly positive.

The new scalar norm proposals in source501 retain the same corrected product and square attachment. Their completeness arguments likewise produce a nonzero norm-tree value and positive scalar input before filling the scalar pole. This operation changes neither that input nor its defining circuit. It uses the pole witnesses only after they have been produced.

Consequently the same set of positive-pole completeness witnesses suffices for all four factorizations. No positivity condition is imposed on arbitrary rational solutions of the new polynomial; soundness uses only polynomial reconstruction. The full inherited arithmetic and the source501 composition still require their own accepted reviews.

## Executable verification

Run

```
python -B build.py
python -B build497.py
python -B verify497.py
```

`verify497.py` first executes the independent verifier for the three detector transformations. It then checks the scalar transformation, complete unchanged-row comparison, actual scalar normalization, exceptional zero branch, coordinate coverage, degree, primitive content, and every coefficient in the final sum of squares. Neither verifier imports a producer.

Both stages pass. Output is saved in `verification497.txt`. This is an exact algebraic certificate plus an explicit positivity-based completeness map, not independent acceptance of the candidate or of the inherited arithmetic theorem.
