'use strict';
// Structural checker authored separately from build-candidate.cjs. It does not
// establish the arithmetic completeness argument in REPORT.md.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'../../quartic-version6-release/repository');
const srcFile=path.join(root,'quartics/quartic-523-540/final523_540/symbolic523/candidate-ir.json');
const bytes=fs.readFileSync(srcFile), src=JSON.parse(bytes), out=JSON.parse(fs.readFileSync(path.join(__dirname,'candidate-518.json')));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
assert.equal(hash(bytes),out.sourceSha256);
const abs=a=>a<0n?-a:a;
function gcd(a,b){a=abs(a);b=abs(b);while(b)[a,b]=[b,a%b];return a;}
function rat(s){const[a,b='1']=String(s).split('/');const n=BigInt(a),d=BigInt(b),g=gcd(n,d)*(d<0n?-1n:1n);return[n/g,d/g];}
function qadd([a,b],[c,d]){const n=a*d+b*c,e=b*d,g=gcd(n,e);return[n/g,e/g];}
function qmul([a,b],[c,d]){const n=a*c,e=b*d,g=gcd(n,e)*(e<0n?-1n:1n);return[n/g,e/g];}
const key=t=>`${t.sPower||0}|${t.monomial.join(',')}`;
function map(ts){const m=new Map();for(const t of ts)m.set(key(t),rat(t.coefficient));return m;}
function equiv(a,b){assert.equal(a.size,b.size);for(const[k,q]of a)assert.deepEqual(q,b.get(k));}
function times(ts,v,c=1n){return ts.map(t=>({...t,monomial:[...t.monomial,v].sort((a,b)=>a-b),coefficient:String(rat(t.coefficient)[0]*c)+'/'+rat(t.coefficient)[1]}));}
const removedVars=new Set(),removedRows=new Set(),replaced=new Map();
for(let i=0;i<5;i++){
 const a=src.coordinates.find(c=>c.name===`V${i}.dxInverse.0`).id;
 const b=src.coordinates.find(c=>c.name===`V${i}.dxInverse.1`).id;
 const r0=src.residuals.find(r=>r.name===`V${i}.dxInverse.definition.0`);
 const r1=src.residuals.find(r=>r.name===`V${i}.dxInverse.definition.1`);
 const extract=(row,v,c=1n)=>row.terms.filter(t=>t.monomial.includes(v)).map(t=>({...t,monomial:t.monomial.filter(x=>x!==v),coefficient:String(rat(t.coefficient)[0])+'/'+(rat(t.coefficient)[1]*c)}));
 const one=r0.terms.find(t=>t.monomial.length===0&&!(t.sPower||0));assert(one);assert.notEqual(rat(one.coefficient)[0],0n);
 const A=extract(r0,a), B=extract(r0,b,2n);
 equiv(map(r0.terms),map([...times(A,a),...times(B,b,2n),one]));
 const expected=map([...times(B,a),...times(A,b)]),actual=map(r1.terms);
 const [pk,pv]=expected.entries().next().value,av=actual.get(pk);assert(av);
 const factor=qmul(av,[pv[1],pv[0]]);
 for(const[k,v]of expected)expected.set(k,qmul(v,factor));
 equiv(actual,expected);
 for(const r of src.residuals)if(r.terms.some(t=>t.monomial.includes(a)||t.monomial.includes(b)))assert([r0.id,r1.id].includes(r.id));
 const nr=out.residuals.find(r=>r.id===r0.id);
 equiv(map(nr.terms),map([...times(A,a),one]));
 removedVars.add(b);removedRows.add(r1.id);replaced.set(r0.id,nr);
}
assert.deepEqual(out.coordinates.map(c=>c.id),src.coordinates.filter(c=>!removedVars.has(c.id)).map(c=>c.id));
assert.deepEqual(out.residuals.map(r=>r.id),src.residuals.filter(r=>!removedRows.has(r.id)).map(r=>r.id));
for(const r of src.residuals)if(!removedRows.has(r.id)&&!replaced.has(r.id))assert.deepEqual(out.residuals.find(t=>t.id===r.id),r);
const valid=new Set(out.coordinates.map(c=>c.id)),used=new Set();
const poly=new Map();let integerRows=[];
for(const r of out.residuals){
 let lcm=1n;for(const t of r.terms){const d=rat(t.coefficient)[1];lcm=lcm/gcd(lcm,d)*d;assert(t.monomial.length<=2);for(const v of t.monomial){assert(valid.has(v));used.add(v);}}
 let ts=r.terms.map(t=>({...t,coefficient:rat(t.coefficient)[0]*(lcm/rat(t.coefficient)[1])}));
 const g=ts.reduce((g,t)=>gcd(g,t.coefficient),0n);ts=ts.map(t=>({...t,coefficient:t.coefficient/g}));
 integerRows.push({id:r.id,terms:ts.map(t=>({...t,coefficient:String(t.coefficient)}))});
 for(let i=0;i<ts.length;i++)for(let j=i;j<ts.length;j++){
  const a=ts[i],b=ts[j],k=`${(a.sPower||0)+(b.sPower||0)}|${[...a.monomial,...b.monomial].sort((a,b)=>a-b).join(',')}`;
  const c=(poly.get(k)||0n)+a.coefficient*b.coefficient*(i===j?1n:2n);if(c)poly.set(k,c);else poly.delete(k);
 }
}
assert.equal(valid.size,518);assert.equal(used.size,518);assert.equal(out.residuals.length,487);assert(valid.has(0));
const terms=[...poly].map(([k,c])=>{const[s,m]=k.split('|');return{sPower:Number(s),monomial:m?m.split(',').map(Number):[],coefficient:String(c)};});
const polynomial={format:'symbolic-integer-polynomial-v1',fixedConstant:'S=3^(2^26)',terms};
fs.writeFileSync(path.join(__dirname,'quartic-518-symbolic.json'),JSON.stringify(polynomial)+'\n');
fs.writeFileSync(path.join(__dirname,'integer-residuals-518.json'),JSON.stringify(integerRows)+'\n');
const summary={structuralVerified:true,arithmeticAcceptance:'pending_independent_review',coordinates:518,witnesses:517,residuals:487,degree:Math.max(...terms.map(t=>t.monomial.length)),coefficientSPowers:Math.max(...terms.map(t=>t.sPower)),symbolicCoefficientTerms:terms.length,distinctVariableMonomials:new Set(terms.map(t=>t.monomial.join(','))).size,sourceSha256:hash(bytes),manuscriptSha256:hash(fs.readFileSync(path.join(root,'manuscripts/quartic_v11.tex')))};
fs.writeFileSync(path.join(__dirname,'verification.json'),JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify(summary,null,2));
