from pathlib import Path
import hashlib,json,sys,zipfile,io
root=Path(__file__).resolve().parent
dest=Path(sys.argv[1] if len(sys.argv)>1 else 'restored').resolve()
if dest.exists():raise SystemExit('Choose a new output directory')
manifest=json.loads((root/'MANIFEST.json').read_bytes())
def check(raw,digest):
    if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('Hash mismatch')
def save(name,raw):
    p=(dest/name).resolve()
    if not p.is_relative_to(dest):raise ValueError('Unsafe path')
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
def layer(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        m=json.loads(z.read('MANIFEST.json'))
        for name,digest in m['files'].items():check(z.read(name),digest)
        for name in m['files']:
            if name.endswith('-base.zip'):layer(z.read(name))
        has_current=any(n.startswith('current/') for n in m['files'])
        for name in m['files']:
            if name.endswith('-base.zip') or name in ('restore.py','README.txt'):continue
            if has_current and not name.startswith('current/'):continue
            save(name[8:] if name.startswith('current/') else name,z.read(name))
for name,digest in manifest['files'].items():
    p=(root/name).resolve()
    if not p.is_relative_to(root):raise ValueError('Unsafe path')
    check(p.read_bytes(),digest)
layer((root/'version11-base.zip').read_bytes())
for name in manifest['files']:
    if name.startswith('current/'):save(name[8:],(root/name).read_bytes())
print('Restored Version 12 and historical bases. Research notes remain alongside this script.')
