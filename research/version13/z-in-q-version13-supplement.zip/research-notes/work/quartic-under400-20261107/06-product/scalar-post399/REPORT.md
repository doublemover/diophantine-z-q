# Bounded scalar search after 399

No new variable saving was obtained in this pass. This is a scoped negative result, not a lower bound for quartic definitions or arbitrary quadratic encodings.

## Frozen source and exact substitution census

The inspected source is `10-combination/combined399-ir.json`, SHA256 `eae983889586748f5a51aa7562d23769ae46f7fba08fc8efcedbb53bc54a5a3b`. It has 399 coordinates and 368 residuals. The later preparation-zero and normalized-pole composition is not part of this source.

`audit_eliminations.py` tests every source row in which a coordinate has exactly one occurrence, with a nonzero rational constant coefficient multiplying that coordinate alone. It solves that row for the coordinate and substitutes the resulting polynomial into every other consumer. It collects exact rational coefficients, including cancellations, before measuring degree in the quantified coordinates. The fixed giant parameter is treated as a coefficient symbol. All 238 eligible definitions fail: at least one remaining consumer has degree greater than two. The complete records and offending consumer degrees are in `ELIMINATION-AUDIT.json`. This rules out only these literal, single-coordinate substitutions. It does not test combinations of residuals, simultaneous changes of coordinates, inversions, or changes justified on the arithmetic domain.

For the scalar norm tree specifically, the explicit square of the second ratio coefficient is multiplied by r in the first norm node. The q-squared coordinate is multiplied by r in the second node. Eliminating either by its definition produces cubic terms. The W-squared coordinate is multiplied by the nonconstant affine expression representing r squared plus 4896r. Eliminating it also produces cubic terms. The stored scalar input is used quadratically by the unnormalized pole and linearly times a pole witness after normalization; substituting its product definition likewise increases degree. These statements concern the present coordinates only.

## Polynomial power circuit boundary

The accepted label is beta = 204X^2 + 204X + 2555. The scalar contact product is

    r = beta(beta-1)(beta-2401)(32beta+343)(2beta-1).

It has degree ten in X and nonzero leading coefficient 64 times 204^5. Hence r^32 has degree 320. The present polynomial circuit uses precisely nine non-input coordinates to obtain this power: input-square248, the three contact intermediates487,488,489, and powers600,601,602,603,604. The published affine normalization of r does not change its degree.

In an explicit straight-line circuit starting from X and rational constants, each new coordinate defined by a polynomial of total degree at most two in previous coordinates can at most double the greatest degree in X. After k such coordinates every available polynomial has degree at most 2^k. As 2^8 < 320 <= 2^9, at least nine such coordinates are necessary if the circuit must explicitly output this same polynomial r^32. The present nine-coordinate circuit reaches that bound. This excludes an improvement by merely replacing that isolated explicit polynomial circuit with a shorter one of the same kind. It does not cover implicit systems, rational functions, output rescaling absorbed in another interface, or an arithmetic change to the exponent or label.

For comparison, replacing both r^32 denominators in the existing two-node norm by r^16 permits only the depth12 bound from the same valuation argument, below the exponent19 in the retained height estimate. Therefore that particular shortening does not preserve the current proof. This is not a restriction on a different norm tree or a sharper height argument.

## Duplicate lead and unchanged artifacts

Homogeneously rescaling the three anchor witnesses by the scalar reciprocal coefficient g0 removes the explicit f1 coordinate while reusing its inverse slot. The resulting anchor is U^2 + 6V^2 - 2W^2 - 12g1^2 - 4CW/g0 = 0. This lead was found independently here, then identified as exactly the already frozen `02-squares/beyond399/REPORT398.md` proposal. No duplicate candidate or review claim was produced.

No source, earlier packet, released manuscript, contract, or acceptance record was changed. The only outputs of this pass are this report, the source consumer census, and the exact finite substitution audit. No new arithmetic theorem application is proposed.
