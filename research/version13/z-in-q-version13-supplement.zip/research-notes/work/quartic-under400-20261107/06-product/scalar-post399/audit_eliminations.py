from pathlib import Path
from fractions import Fraction as F
import json,hashlib
H=Path(__file__).resolve().parent
S=H.parents[1]/'10-combination/combined399-ir.json'
d=json.loads(S.read_text())
assert hashlib.sha256(S.read_bytes()).hexdigest()=='eae983889586748f5a51aa7562d23769ae46f7fba08fc8efcedbb53bc54a5a3b'
def add(a,b):
 q=a.copy()
 for m,v in b.items():q[m]=q.get(m,F(0))+v
 return {m:v for m,v in q.items() if v}
def mul(a,b):
 q={}
 for m,v in a.items():
  for n,w in b.items():
   k=tuple(sorted(m+n));q[k]=q.get(k,F(0))+v*w
 return {m:v for m,v in q.items() if v}
def dec(ts):return {tuple([-1]*t.get('sPower',0)+t['monomial']):F(t['coefficient']) for t in ts}
def sub(q,i,g):
 out={}
 for m,v in q.items():
  term={tuple(x for x in m if x!=i):v}
  for _ in range(m.count(i)):term=mul(term,g)
  out=add(out,term)
 return out
def degree(q):return max((sum(i>=0 for i in m) for m in q),default=0)
rows={r['name']:dec(r['terms']) for r in d['residuals']}
records=[]
for c in d['coordinates']:
 i=c['id'];uses={n:q for n,q in rows.items() if any(i in m for m in q)}
 for n,q in uses.items():
  its=[m for m in q if i in m]
  if its!=[(i,)]:continue
  g={m:-v/q[(i,)] for m,v in q.items() if m!=(i,)}
  outputs={rn:degree(sub(rq,i,g)) for rn,rq in uses.items() if rn!=n}
  records.append({'coordinate':i,'name':c['name'],'definingRow':n,'replacementDegree':degree(g),'consumerDegrees':outputs,'accepted':all(k<=2 for k in outputs.values())})
result={'source':'work/quartic-under400-20261107/10-combination/combined399-ir.json','sourceSha256':hashlib.sha256(S.read_bytes()).hexdigest(),'scope':'Every single-coordinate substitution from a row with a sole occurrence of that coordinate, linear with nonzero rational constant coefficient. All other rows are literally substituted and exact cancellations collected. No row combinations or arithmetic domain replacement.','definitionsTested':len(records),'accepted':[r for r in records if r['accepted']],'records':records}
(H/'ELIMINATION-AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
