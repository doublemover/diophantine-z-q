"""Author-side application descriptions, bound by build.py to frozen passages."""
SPECS=[]
def a(id,section,span,consumers,kind,required,constructed,mapping,exceptions,prior=()):
    SPECS.append(dict(id='V13-'+id,section=section,span=span,consumers=consumers,kind=kind,
                      required=required,constructed=constructed,mapping=mapping,
                      exceptions=exceptions,prior=list(prior)))

a('MODEL','inputs',(14,27),[(271,285),(732,758)],'inherited arithmetic',
  'The stated curve over Q(sqrt(2)), the fixed generator P, its halving R0, rational two-torsion, and the inherited rank and squareclass calculations.',
  'The same K, rho, d0, D and P; odd nonzero root indices n,a,t,b; scalar index s=a-1.',
  'Retain the exact model and group law. Later H=mR0+T uses the full group decomposition rather than asserting H is a double.',
  'The source qualifications in the Version12 input section remain. No rank or generator claim is inferred from polynomial computation.',('V12-INT-POINTS',))
a('HEIGHT','inputs',(29,40),[(510,527),(291,314)],'inherited arithmetic',
  'Three contact radicals, the retained product-height scales and nonzero integer N divisible by their kth powers.',
  'Scales 1,C0^2,(1+C1^2)^2 for the same product of root abscissae; B=max absolute root indices and Hcal<2^2093966.',
  'Apply B^2-6<7 Hcal |N|^(19/k) with k=40,10 or24 only after the respective divisibility is established.',
  'N=0 is never submitted to the height implication. Root indices remain nonzero; no deleted field witness changes the product.',('V12-INT-PRODUCTHEIGHT','V12-INT-SCALARHEIGHT'))
a('LOG-APPROX','logs-order10',(42,83),[(84,111),(333,348)],'new arithmetic bridge',
  'The integral formal expansion and full-tail estimate for the same z=-x/y, f=1/x; residue characteristic p>76176, unramified places.',
  'The printed N8/Q2 rational function and exact QG9-N identity, with coefficient denominators supported at primes at most37.',
  'For depth r, v(Df^2)=4r; the remainder has relative order40 and absolute logarithm error at least41r. Positivity handles doubled real points; the later modular argument handles general H.',
  'At O the analytic unit is defined by its power series and the error is exactly zero. No literal log(O)/z(O) division.',('V12-INT-TRUNCATION','V12-EXT-LOG-DEPTH'))
a('LOG-TRANSFER','logs-order10',(84,111),[(350,366),(510,527)],'new arithmetic bridge',
  'Formal logarithm additivity and isometry, the two group identities, and one integral full ratio because h and h-1 differ by1.',
  'Analytic units A, G2/A and R/A; first opposite test order12, first cross/input tests order10, remaining cross tests order40.',
  'Transfer integrality before deducing depth; subtract after multiplication by h and h-1 to recover n modulo p^10 and the other indices modulo p^40.',
  'Zero U or V gives zero numerator with unit extension, not division by a zero parameter. The later half-index identities replace the initial doubled-H notation.',('V12-EXT-LOG-MIX','V12-INT-DETECTOR'))
a('ODD-NORM','odd-roots',(113,138),[(14,27),(732,758)],'new arithmetic bridge',
  'The inherited finite root chart and squareclass decomposition [epsilon]^m[-1]^e[d0]^f.',
  'A^2-2(x+j)A-D=0 and Norm(A)=-u^2 on the same root Q.',
  'Set t=(A-x-j)/h; the resulting point doubles to Q. The norm forces m odd and f=0. If needed replace A by 2(x+j)-A, whose product with A is -D.',
  'h and j are nonzero by the real and norm argument. The two squareclass choices are reconciled without claiming a unique private inverse.',('V12-INT-POINTS',))
a('SHARED-RECIPROCAL','shared-reciprocals',(139,155),[(156,173),(444,475)],'exact rational bridge',
  'A finite H chart with nonzero hH,jH, and the old primary/scalar reciprocal equations.',
  'One shared S=jH/hH=-1/z(H), with j_i L_i=h_i S and the fused scalar equation T rho-a*N*S=0.',
  'Recover each eliminated parameter from the retained ratio and S; the scalar inverse is zR=-rho/S. All outside ratios are fixed.',
  'Division uses only the proved nonzero shared value. The subsequent H-domain exclusion reestablishes S nonzero on the enlarged domain.',('V12-ALG-RECIPROCAL',))
a('IDENTITY-CHARTS','identity-domains',(156,190),[(219,269),(84,111)],'new arithmetic bridge',
  'The doubled-point curve chart and actual subtraction from a nonzero odd root.',
  'f=r^2, J^2+Df^2=1 and the displayed d,g,u,k subtraction equations.',
  'For r nonzero recover the finite chart; for r=0 use U=O. The equations recover the actual V=U-Q by regularity and the printed boundary values.',
  'J and k cannot vanish because 7 Norm(r)^2=1 is impossible. g=0 means V=O; U=-Q uses the regular doubling limit. d is positive at both embeddings.',('V12-INT-POINTS','V12-ALG-RECIPROCAL'))
a('V0-EXCLUSION','identity-domains',(200,217),[(84,111),(286,314)],'new arithmetic bridge',
  'The one-place order40 test, explicit f(P) and the retained root-height and anchor lower bounds.',
  'The possible V0=O branch would make H=P and f(H) a unit at every consumed place.',
  'All three contact radicals would be1; apply the height inequality with N=1 and contradict B>=|a|. This precedes every LP quotient.',
  'Do not use the obsolete V1 nonidentity argument. For general H the stronger torsion-translate exclusion and modular nonvanishing replace the positivity step.',('V12-INT-DETECTOR','V12-INT-PRODUCTHEIGHT','V12-INT-ANCHOROLD'))
a('BIQUADRATIC','scaled-biquadratic',(219,269),[(84,111),(529,546)],'exact rational bridge',
  'Root constants c=a^2, b^2=c^2-D, a nonzero, and the identity-inclusive reciprocal comparison chart.',
  'V=ar, Qprime=ag, I=aJ, Kprime=ak, W=rg, with retained actual field-square outputs YU,YV.',
  'The three displayed polynomial identities recover both conics and subtraction. Divide by a to recover r,g,J,k; compare the conics to obtain YU=r^4 and YV=g^4.',
  'No division by r,g,J,k,W,L,z or the outputs; r=0 and g=0 retain their identity meanings. d,e are positive. This replaces, rather than adds to, the overlapping inverse-addition saving.',('V12-INT-POINTS',))
a('H-HALF-INDEX','H-domain',(271,285),[(350,366),(474,489)],'new arithmetic bridge',
  'The inherited full Mordell-Weil decomposition E(K)=Z R0+E[2], with 2R0=P.',
  'Retain xf=1 and S^2=x-Df after removing the H square witnesses; write H=mR0+T.',
  'Use h=m/2 only as a rational index. Every actual elliptic multiplication remains by an integer.',
  'No assertion that general H lies in 2E(K). Completeness retains the former doubled H and forgets its square witnesses.',('V12-INT-POINTS',))
a('H-TORSION-EXCLUSION','H-domain',(286,314),[(315,332),(350,366)],'new arithmetic bridge',
  'The exact torsion translation formulas, the one-place detector and height-anchor contradiction.',
  'Finite points of E[2] and of plus/minus P+E[2]; printed norms of cstar and cstar plus/minus d0.',
  'All candidate f(H) are units outside {2,3,7,17,41}; order40 makes every radical1, contradicting the existing height and anchor inequalities.',
  'O and (0,0) are already excluded by xf=1. Exclude all listed torsion translates before interpreting denominators, not after using their quotients.',('V12-INT-DETECTOR','V12-INT-PRODUCTHEIGHT'))
a('H-SUBTRACTION','H-domain',(315,332),[(333,366),(444,489)],'new arithmetic bridge',
  'The retained rescaled V0 equations on the enlarged H chart and the preceding finite exceptional-set exclusion.',
  'd=cstar*x+D, N=astar*S-bstar, dv=N, Tprime=-2D-astar*bstar*S+2D*bstar*v.',
  'The explicit subtraction formulas identify x,y,z of H-P and hence the retained f(V0) and ell0 equations.',
  'd=0 and N=0 force already excluded translates. Equal abscissa x=cstar gives plus/minus P. Nontorsion H-P has nonzero ordinate and Tprime; no real positivity is assumed.',('V12-ALG-RECIPROCAL',))
a('H-NO-ROOT','H-domain',(333,348),[(350,366),(84,111)],'new arithmetic bridge',
  'The exact rational polynomials N8,Q2, integral coefficients and unit leading coefficient at the selected split primes.',
  'N8 has no root modulo71; Q2 has no root modulo7. The split square roots of2 are12,59 and3,4 respectively.',
  'A K-root maps to a local root. The leading-unit condition makes that root integral, so reduction contradicts the complete residue enumeration.',
  'These are two separate local arguments, one for each polynomial. They imply global nonvanishing on K without the old real interval assumption.',('V12-INT-TRUNCATION',))
a('H-LOG-IDENTITIES','H-domain',(350,366),[(474,489),(510,527)],'new arithmetic bridge',
  'Formal points, odd consumed p and the full-group expression H=mR0+T with T killed by2.',
  '[m]Ui=[2ui]H, [m-2]Vi=[2(ui-ni)]V0 and [m](2R)=[4s]H.',
  'Logarithm additivity gives ui/h, (ui-ni)/(h-1), s/h with h=m/2. h is p-integral and one of h,h-1 is a unit.',
  'The identities kill torsion and use integer multiplications only. Apply the scalar identity to 2R, allowing both O and (0,0) local branches of R.',('V12-EXT-LOG-MIX','V12-EXT-LOG-SCALAR'))
a('INPUT-PARITY','one-correction',(368,389),[(510,527),(800,818)],'new arithmetic bridge',
  'The final equality n=beta and the retained odd integer label n, not merely integrality of beta.',
  'tau=2X+1 and beta=51tau^2+2504; input-square Y=X^2 is retained.',
  'In lowest terms tau=u/v, integrality gives v^2 dividing squarefree51; then parity of beta forces tau odd and X integral. The printed affine Y substitution applies to every other consumer.',
  'X=-1/2 exhibits failure of the parity-free inference. For rational inputs beta>=2504; at consumed p coefficient51 is a unit.',('V12-INT-POINTS',))
a('INPUT-LOCAL-ONE-CHOICE','one-correction',(390,410),[(411,425),(628,672)],'new arithmetic bridge',
  'Integer X and odd tau; the standard unit-square criteria in Q2,Q3,Q17.',
  'v2(r)=2 with r/4=1 mod8, v3(r)=1 with nonzero unit1+tau^2 mod3, and r=15 mod17.',
  'The intermediate c=33033 for 3|tau and33 otherwise corrects the simultaneous local classes. This intermediate choice is then superseded by c=r+4896.',
  'The local calculation is restricted to integer inputs. beta is not asserted always2 mod9. The one-choice coordinate is not part of the final deterministic circuit.' )
a('DETERMINISTIC-CORRECTION','deterministic-correction',(411,443),[(459,489),(628,672)],'new arithmetic bridge',
  'Positive r, the preceding integer-input local valuations, and consumed scalar contact primes p>76176.',
  'c=r+4896; the normalized quadratic row (r2+4896r)V+82479248 b0=0.',
  'c/r lies in1+8Z2 and1+pZp at3,17, so cr is locally square. First prove odd v_p(r)>0, then c is a unit since4896 is a unit at consumed p.',
  'No claim that c is a unit at every large prime. New prime factors of c are included before the continuity modulus and contact primes. The old finite-choice equation is not restored.' )
a('SCALAR-NORM24','scalar24',(444,478),[(479,500),(645,672)],'new arithmetic bridge',
  'Odd positive eta=v_p(r), c a unit at the consumed prime, and the actual pole input crW^2.',
  'Bs=(z0^2+rz1^2)/r32, W=(Bs^2+rq^2)/r32 and q=Norm(fH). The product-slot norm identity has coefficient8.',
  'Opposite valuation parity prevents cancellation. The pole bound yields v(Bs)>63eta/4, v(q)>61eta/4, v(z0)>191eta/8, v(z1)>187eta/8 and both coefficient depths at least24.',
  'A zero summand has valuation infinity. r>0 and q nonzero imply W>0 globally. Norm positivity only selects a place; it does not make R formal.',('V12-INT-SCALARCONTACT','V12-ALG-NORMSQUARE'))
a('SCALAR-TORSION-LOG','scalar24',(474,489),[(490,500),(510,527)],'new arithmetic bridge',
  'A place where H is formal and the actual scalar ratio has depth24; odd good residue characteristic.',
  'R=[s]P may approach O or (0,0). The duplication formulas give 2R formal with the same parameter valuation.',
  'Apply logarithm isometry to [m](2R)=[4s]H to obtain v_p(s/h)>=24 and then v_p(s)>=24 because h=m/2 is p-integral.',
  'Do not infer R formal from positive v(zR). Both signs of v(xR) are handled. H is not assumed a double.',('V12-EXT-LOG-SCALAR','V12-INT-SCALARCONTACT'))
a('SCALAR-HEIGHT','scalar24',(483,500),[(510,527),(645,651)],'new arithmetic bridge',
  'The established contact divisibility to depth24 and the inherited scalar height theorem and anchor size.',
  'h(beta)<=Hcal|s|^(19/24) and log2|s|>25165823.5.',
  'The printed numerical margin gives h(beta)<|s|/80<=|a|/40 and log(48Hcal)<|a|/40 for the order10 contradiction.',
  'The depth reduction does not change the order40 Lucas test. Nonzero s is established by the point guard before applying the anchor.',('V12-INT-SCALARHEIGHT','V12-INT-ANCHOROLD'))
a('ANCHOR-COEFFICIENT','anchor-rescaling',(732,758),[(759,798),(29,40)],'inherited arithmetic',
  'The Version12 coefficient lemma for every nonzero even integer s, with no anchor divisibility hypothesis.',
  'The new guard g0*tau=1 gives g nonzero, so R=S-P has nonzero even index and f1(R)=2g0g1.',
  'Apply v3(f1([s]P))=2+2v3(s), using the same inert residue field and formal leading term, to obtain g1 nonzero.',
  'S=P is excluded by g nonzero; S=-P is interpreted by actual doubling to -2P. Negative s is allowed. This must precede restoration of the old inverse.',('V12-EXT-FORMAL3','V12-INT-ANCHOROLD'))
a('HEIGHT-CONTRADICTIONS','completion',(510,527),[(800,818)],'new arithmetic bridge',
  'Nonzero odd root labels, retained Lucas lemma, height inequality and new scalar height margin.',
  'First the order40 divisibility of F; then, if n differs from beta, order10 divisibility of its nonzero reduced numerator N.',
  'F nonzero contradicts the B bound, so F=0 and log B>|a|-3. The second inequality gives log B<29|a|/40, proving n=beta and then integer X.',
  'Apply height only to nonzero integers. The Lucas lemma consumes the same nonzero odd b; the final input bridge additionally consumes odd n.',('V12-INT-LUCAS','V12-INT-PRODUCTHEIGHT'))
a('GROUPED-POLYNOMIALS','triples',(529,553),[(554,575),(819,827)],'exact polynomial bridge',
  'The unchanged field test values, conjugations and three detector arguments.',
  'Order1 uses the listed three triples, order10 its pair, and order40 its pair and triple; shared elementary coefficients evaluate product(1+qYi).',
  'Eliminate private d=bc via e2-a(b+c), with e3=a e2-a^2(b+c), using the retained square of the selected first member.',
  'Check every affine-normalized W consumer. No test is replaced by product(q-Yi); no root or reciprocal domain changes.',('V12-INT-DETECTOR',))
a('TORIC-POWERS','triples',(554,565),[(529,553),(819,827)],'exact rational bridge',
  'Nonzero E and q supplied by the unchanged scale/norm guards.',
  'The printed Ea=q, Eb=a^2, qc=b^2, cd=q2*q3 and subsequent q10,q40 equations.',
  'Recover c=q^3/E^6, d=q^2E^6, q10=qE^18 and q40=qE^78; replace q^5 by the product of existing q2 and q3.',
  'Only already nonzero E,q are divided out. The final fourth power still uses a quadratic square slot.',('V12-ALG-TORIC',))
a('CONSTANT-PIVOT','triples',(567,575),[(819,827)],'exact polynomial bridge',
  'An eliminated defining row with nonzero rational constant pivot and complete identities for every consumer.',
  'Fnew=Fold after substitution plus a polynomial combination of retained vanishing residuals.',
  'Forget the coordinate forward and reconstruct its unique polynomial expression backward; all exterior coordinates stay fixed.',
  'A count decrease is not a consumer check. Only the pinned complete row certificates justify applying this scheme to each component.',('V12-ALG-COMPILE',))
a('FACTORED-POLES','poles',(577,597),[(675,700),(800,818)],'new arithmetic bridge',
  'The normalized old conic rows and positive semantic pole input from the arithmetic construction.',
  'F=t*v, q=t*Q, q2=t^2*Q2, with the printed quadratic conic and factor equation.',
  'Substitution multiplies the new conic by t^2. Divide when t nonzero; when t=0 positivity forces old F=q=0 and permits the zero lift.',
  'New solutions always reconstruct old ones, including t=0. Completeness uses semantic positivity; the stored scalar input has the opposite sign.',('V12-ALG-POLE',))
a('PREPARATION-CONIC','poles',(599,612),[(689,700)],'exact rational bridge',
  'The old four-row scalar preparation with nonzero semantic input b and only its prepared square N consumed outside.',
  'U^2=N, bJ=1, JN+Y^2=b.',
  'Forward U=W-b,J=T-t2,Y=tW. Reverse uses d=b+U and the printed formulas; only the square N must remain fixed.',
  'When d=0 use W=2b,t=0,T=J rather than dividing by d. The inverse of b remains until separate preparation-zero soundness restores it.',('V12-ALG-POLE',))
a('REAL-INITIAL','preparation-zero',(614,651),[(674,688)],'new arithmetic bridge',
  'The inherited real-progression open-set statement for G0, with m0=|G/G0| dividing residue and modulus, and finite-index formal subgroups.',
  'Choose H0 first in a sufficiently deep multiple of64m0, then R in a sufficiently deep multiple of6m0, both real-close to O.',
  'First make q(H0) small; with its nonzero denominators fixed, make z(R)/z(H0) small and obtain b(H0,R)<17/4 while meeting anchor and all finite depths.',
  'The same H0 and R satisfy all conditions. R is chosen after H0. Arbitrarily large positive indices retain the anchor size; no separate incompatible real/local witnesses are combined.',('V12-INT-SCALARCOMPLETE',))
a('FINITE-SUPPORT','preparation-zero',(628,672),[(674,688),(689,700)],'new arithmetic bridge',
  'The finite support of the actual deterministic cr and explicit local squareclasses and valuation thresholds.',
  'Use S=supp(cr) union {2,3,17}; fH coefficient depth8eta, scalar ratio depth24eta, and extra positive depth at17.',
  'W is integral on supp(cr), denominator valuations of b outside it are even, and v2(b)>=4,v3(b)>=2,v17(b)>=8 meet thresholds3,1,2.',
  'Prime17 is included even though it need not divide cr. W need not be a unit. Additional prime divisors of c are allowed and handled before L and contact-prime choice.',('V12-INT-SCALARCOMPLETE',))
a('REAL-FINAL-CRT','preparation-zero',(674,688),[(689,700),(800,818)],'new arithmetic bridge',
  'The real-progression open-set/pole-avoidance statement and the inherited simultaneous-prime and separation theorems for an arbitrary fixed sufficiently divisible L.',
  'Fix R, choose U with0<b<17, then a nonempty Uprime with compact closure avoiding all poles; fix bounds and L before contact primes.',
  'Solve the displayed three compatible congruences. Since m0 divides h0,L, it divides the final residue and modulus, so a positive tail meets Uprime.',
  'All bounds are fixed before the prime choice, and the same final H retains every local and real requirement. Do not invoke density on a wrong component of G.',('V12-INT-PRIMES','V12-INT-SCALARCOMPLETE'))
a('PREPARATION-ZERO','preparation-zero',(614,626),[(689,700),(702,730)],'new arithmetic bridge',
  'The exact inherited preparation-zero lemma: b positive below17, square reduced denominator, square in Q2,Q3,Q17 and valuations at least3,1,2.',
  'The one final pole input b=crW^2 satisfying the REAL-INITIAL, FINITE-SUPPORT and REAL-FINAL-CRT applications.',
  'The lemma supplies fresh pole witnesses with prepared value b. Replace the physical three-row preparation by n=x^2; restore U=b,J=1/b,V=0 for soundness.',
  'This is equality of integer-input projections, not specialization of every arbitrary old private witness. b>0 is proved from outside rows before deleting the inverse.',('V12-INT-SCALARCOMPLETE',))
a('NORMALIZED-SCALAR-POLE','normalized-pole',(702,730),[(800,827)],'exact rational bridge',
  'Preparation already specialized to n=x^2 and semantic b=-Kx>0 proved outside the private pole.',
  'Scale the five listed private slots by x and their two square slots by x^2; remove n.',
  'Each old remaining residual is x^2 times the new quadratic residual. Inverse maps divide or multiply by the corresponding nonzero power of x.',
  'No private pole variable is divided out, so all of their zero cases survive. Negative stored x is permitted. Complete seven-slot consumer incidence is required.' )
a('ANCHOR-RESCALING','anchor-rescaling',(759,783),[(29,40),(784,798)],'new arithmetic bridge',
  'The actual nonzero even scalar point and coefficient nonvanishing, established before applying this algebraic map.',
  'g0*tau=1 and U^2+6V^2-2W^2-12g1^2-4C*tau*W=0.',
  'Scale old u,v,w by g0, restore F=2g0g1 and sigma=1/F. The printed residual identity reduces the difference to4C*g0*W*(g0*tau-1).',
  'All anchor witness zero values are allowed. This is not a bijection on an isolated anchor with arbitrary g1=0; the full point-domain coefficient lemma excludes that case.',('V12-INT-ANCHOROLD','V12-EXT-QUATERNION'))
a('ORDINARY-GATE','anchor-rescaling',(784,798),[(819,827)],'exact polynomial bridge',
  'C is a fixed integer in the symbolic polynomial, but a computed coordinate in the ordinary companion.',
  'c0=3^1024, cj=c(j-1)^2 through j15, plus the separate TC=C*tau gate.',
  'Use -4TC*W in the ordinary anchor. The chain and extra gate uniquely reconstruct C and TC; all other coordinates are unchanged.',
  'C*tau*W would be cubic if left literal. Count all16 constant coordinates plus this extra coordinate and all17 defining rows.',('V12-ALG-LIFT',))
a('FINAL-COMPLETENESS','completion',(800,818),[(819,827)],'new arithmetic bridge',
  'Every integer X, the retained Lucas label construction, root scale choices, simultaneous-prime and real-progression statements.',
  'The ordered common choices H0,R, remaining labels and roots, scales, L, contact primes, then one final large h in the prescribed open set.',
  'Use Ui=[h*ni]P and Vi=[(h-1)*ni]P, fresh pole witnesses for changed scalar/log inputs, and then every exact private circuit map.',
  'Completeness may use the old nonidentity doubled points despite the enlarged soundness domain. No arbitrary old pole witness is claimed to survive changed arithmetic inputs.',('V12-INT-LUCAS','V12-INT-PRIMES','V12-INT-SCALARCOMPLETE'))
a('SOS-FINITE','completion',(819,827),[(784,798)],'exact polynomial bridge',
  'The complete final list of rational quadratic residuals and the ordered field Q.',
  'Clear denominators, divide each row by its integer content, square and sum; bind the resulting symbolic and ordinary tables separately.',
  'The quartic vanishes over Q exactly when every primitive residual vanishes. Finite monomial/count/coefficient assertions are bound to exact files, not inferred by adding component savings.',
  'Structural or SOS checking does not prove the external arithmetic assumptions or independently accept this draft. No acceptance record is authored here.',('V12-ALG-COMPILE','V12-ALG-SOS'))

# The author's final theorem preamble inserted eighteen lines before the
# unchanged mathematical subsections. The former final paragraph became the
# final coefficient-table subsection. These spans are pinned to that exact
# 91b278b3... author freeze; build.py rejects any different bytes.
def final_span(s):
    return (s[0]+18,860 if s[1]>=819 else s[1]+18)
for _s in SPECS:
    _s['span']=final_span(_s['span'])
    _s['consumers']=[final_span(x) for x in _s['consumers']]
SPECS[-1]['consumers'].append((7,30))
a('FINITE-COUNTS','completion',(837,860),[(7,30)],'finite certificate',
  'The complete frozen symbolic394 and ordinary411 IR and coefficient files, with a one-to-one consecutive coordinate map.',
  '364 and381 quadratic rows,6338 and6388 monomials, degree4 and content1, with the exact maxima and byte lengths recorded in the artifact manifest.',
  'The pinned finite verifier expands the primitive row squares and compares every coefficient. The ordinary chain adds16 constant coordinates and the separate C*tau coordinate.',
  'These are finite numerical assertions only. They do not independently establish the arithmetic projection or approve the newly assembled exposition.')
a('RECIPROCAL-IDENTITY','shared-reciprocals',(196,205),[(157,173),(750,768)],'exact rational bridge',
  'The finite root and subtraction chart, with astar*d nonzero in both real embeddings.',
  'G=dg-N, K=astar*d*k-T, Z=kz+g and L=Tz+astar*N.',
  'The exact identity L=astar*d*Z-z*K-astar*G permits deletion of k and its private consumers; recover k=T/(astar*d).',
  'The stated nonzero denominator is proved on the finite doubled-point chart. The later enlarged H domain uses its separate exceptional-set proof.',('V12-ALG-DCANCEL','V12-ALG-RECIPROCAL'))
a('H-EXACT-RESCALING','shared-reciprocals',(207,218),[(289,332)],'exact rational bridge',
  'The original finite H chart has nonzero hH and x=hH^2.',
  'Write jH=hH*S and g=hH*v, retaining S^2=x-DfH, (cstar*x+D)v=astar*S-bstar, and fV0*fH=v^2.',
  'Substitute these expressions into the exact difference and logarithm rows, divide by the nonzero common hH factor, and recover the old jH and g by multiplication.',
  'This exact rescaling is performed before deleting the H square witnesses. It does not by itself license a larger H domain or remove the V0 logarithm guard.',('V12-ALG-RECIPROCAL',))
