"""Produce an author-only, repository-relative application inventory overlay."""
from pathlib import Path
import copy, hashlib, json, re, shutil
from specs import SPECS

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
PREP=HERE.parent
REPO=ROOT/'work/quartic-version6-release/repository'
PUBLIC='docs/manuscript-revisions/version13'
PAYLOAD=HERE/'payload'
STAGE=HERE/'staging'
for d in (PAYLOAD,STAGE,HERE/'author-originals'):d.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def objsha(o):return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(p,o):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def stage(src,rel,payload=False):
    target=STAGE/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
    if payload:
        target=PAYLOAD/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
    return {'path':rel,'sha256':sha(src)}

expected={'addition.tex':'91b278b3ca1684df93e32883d8046a2accda970efc1ed9159b095183092d5a09',
          'integration-map.json':'d78cfe0d6bf9ae67d2bde71d0e8d56e539c246e6d258e8208f167b5812625d05',
          'new-application-rows.json':'e8adbe8ef3c02700af8bc90846e586fc9fbb07584d1fe076e3ef2fff3a879d7b'}
for name,h in expected.items():
    assert sha(PREP/name)==h,(name,'changed author input')
    shutil.copyfile(PREP/name,HERE/'author-originals'/name)

mapping={}
def relocate_path(old):
    if old in mapping:return mapping[old]
    src=ROOT/old
    assert src.is_file(),old
    if src.is_relative_to(REPO):rel=src.relative_to(REPO).as_posix();payload=False
    elif src==PREP/'addition.tex':rel=PUBLIC+'/addition.tex';payload=True
    else:
        # Full source bytes are supplied, not just a former workstation path.
        rel=PUBLIC+'/evidence/'+sha(src)[:16]+'-'+src.name;payload=True
    stage(src,rel,payload)
    mapping[old]=rel
    return rel
def relocate(o):
    if isinstance(o,list):return [relocate(x) for x in o]
    if not isinstance(o,dict):return o
    out={k:relocate(v) for k,v in o.items()}
    if 'path' in o:
        out['path']=relocate_path(o['path'])
        out['sha256']=sha(ROOT/o['path'])
    return out

rawmap=json.loads((PREP/'integration-map.json').read_text(encoding='utf-8'))
rawrows=json.loads((PREP/'new-application-rows.json').read_text(encoding='utf-8'))
pmap=relocate(rawmap);prows=relocate(rawrows)
write(PAYLOAD/PUBLIC/'new-application-rows.json',prows)
pmap['component_row_bindings']={'path':PUBLIC+'/new-application-rows.json','sha256':sha(PAYLOAD/PUBLIC/'new-application-rows.json')}
for name,o in [('integration-map.json',pmap),('new-application-rows.json',prows)]:
    p=PAYLOAD/PUBLIC/name;write(p,o);stage(p,PUBLIC+'/'+name)
textpin=stage(PREP/'addition.tex',PUBLIC+'/addition.tex',True)
lines=(PREP/'addition.tex').read_bytes().decode('utf-8').splitlines(keepends=True)
textpin['lineCount']=len(lines)
def passage(a,b,role):
    b=min(b,len(lines))
    assert 1<=a<=b
    return dict(textpin,start_line=a,end_line=b,sha256_raw_utf8_span=hashlib.sha256(''.join(lines[a-1:b]).encode()).hexdigest(),role=role)

v12path=ROOT/'work/quartic-optimization-20261107/06-product/manuscript-v12/portable-inventory/APPLICATIONS.json'
v12=json.loads(v12path.read_text(encoding='utf-8'));by12={r['id']:r for r in v12['applications']}
# Archive the exact prior author inventory without rewriting it.
v12pin=stage(v12path,PUBLIC+'/evidence/v12-APPLICATIONS.json',True)
def stage_repo_pins(o):
    if isinstance(o,list):
        for x in o:stage_repo_pins(x)
    if isinstance(o,dict):
        if 'path' in o:
            p=REPO/o['path'];assert p.is_file(),p
            stage(p,o['path'])
        for x in o.values():stage_repo_pins(x)
stage_repo_pins(v12)
sections={s['id']:s for s in pmap['sections']}
common='K=Q(rho), rho^2=2; D=(3-rho)^2; f=1/x and z=-x/y. At consumed places p>76176 use the inherited unramified valuation normalization and conjugation conventions. C=3^(2^25).'
applications=[]
for s in SPECS:
    section=sections[s['section']]
    prior=[]
    for id in s['prior']:
        old=by12[id]
        prior.append({'id':id,'recordSha256':objsha(old),'inventory':v12pin,'source':old['source'],
                      'status':'Inherited author application and its original source qualifications; not fresh acceptance of Version13.'})
    source={'inheritedPassages':section['source_passages'],'priorApplications':prior,
            'newDerivation':passage(*s['span'],'author derivation in the new section'),
            'status':'The baseline is the released Version12 manuscript. New arguments are author exposition, not externally published theorems. Historical reviews are separate evidence only.'}
    obligations={
      'required_inputs':s['required'],
      'constructed_inputs':s['constructed'],
      'domain_and_index_coverage':s['exceptions']+' The required and constructed objects above are the domain for this application; no larger field or point domain is silently substituted.',
      'transition_maps_and_scalars':s['mapping'],
      'identity_of_consumed_object':s['constructed']+' The consumer passages below use these same objects and the displayed normalization.',
      'exceptional_cases':s['exceptions'],
      'affected_downstream_claims':'The exact consumer spans are bound below; the inherited applications listed here remain dependencies, not new independent approvals.',
      'source_version_and_conventions':common+' Exact file, span and prior-source record hashes are supplied in source and historical evidence. Preserve all Version12 source-status/errata qualifications.',
      'validation_and_acceptance_scope':'Author inventory. Structural checking validates pins, coverage, component objects and consumer binding; it is not proof of the arithmetic application. No Version13 manuscript acceptance is asserted.'}
    applications.append({'id':s['id'],'kind':s['kind'],'sectionId':s['section'],'source':source,
                         'obligations':obligations,
                         'consumers':[passage(a,b,'downstream use') for a,b in s['consumers']],
                         'historicalEvidence':section['reviews'],
                         'acceptanceStatus':'author_only_pending_separate_version13_acceptance'})

# Bind every explicit cross-reference and every label occurring in inherited source spans.
baseline=REPO/'manuscripts/quartic_v12.tex'
baselinepin=stage(baseline,'manuscripts/quartic_v12.tex')
oldtext=baseline.read_text(encoding='utf-8');oldlines=oldtext.splitlines()
newlabels=set(re.findall(r'\\label\{([^}]+)\}',''.join(lines)))
explicit=set(re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',''.join(lines)))-newlabels
labels={}
for label in explicit:
    hits=[i for i,l in enumerate(oldlines,1) if '\\label{'+label+'}' in l]
    assert len(hits)==1,(label,hits)
    labels[('manuscripts/quartic_v12.tex',label)]={**baselinepin,'label':label,'line':hits[0],'relation':'explicit new-section reference'}
for sec in pmap['sections']:
    for sp in sec['source_passages']:
        ls=(STAGE/sp['path']).read_text(encoding='utf-8').splitlines()
        for i in range(sp['start_line'],sp['end_line']+1):
            for label in re.findall(r'\\label\{([^}]+)\}',ls[i-1]):
                key=(sp['path'],label)
                if key not in labels:labels[key]={'path':sp['path'],'sha256':sp['sha256'],'label':label,'line':i,'relation':'label inside the pinned inherited supporting passage'}

release=ROOT/'work/quartic-under400-20261107/10-combination/release394'
artifact=json.loads((release/'ARTIFACTS.json').read_text(encoding='utf-8'))
assert sha(release/'ARTIFACTS.json')=='23078103389747c9176702d20b44e452b1a036a46c010ae4149789ececef3637'
artifactpins=[]
for name,h in artifact['files'].items():
    assert sha(release/name)==h
    artifactpins.append(stage(release/name,'quartics/quartic-394-411/'+name))
artifactpin=stage(release/'ARTIFACTS.json','quartics/quartic-394-411/ARTIFACTS.json')
verification=[]
for name in ['verify_lineage.py','VERIFICATION-PLAN.json','SOURCE-MANIFEST.json',
             'sources/work/quartic-under400-20261107/10-combination/verify_release394.py']:
    verification.append(stage(release/name,'quartics/quartic-394-411/'+name))
reviewpins=[]
for name in ['ACCEPTANCE.json','reviews/mathematical-review.md','reviews/artifact-review.md']:
    reviewpins.append(stage(release/name,'quartics/quartic-394-411/'+name))
data={'schema':'portable-application-inventory-v2','status':'Author-only Version13 inventory; no manuscript acceptance record is created or inferred.',
      'text':textpin,'baselineManuscript':baselinepin,
      'integrationMap':{'path':PUBLIC+'/integration-map.json','sha256':sha(PAYLOAD/PUBLIC/'integration-map.json')},
      'componentRows':{'path':PUBLIC+'/new-application-rows.json','sha256':sha(PAYLOAD/PUBLIC/'new-application-rows.json')},
      'authorInputPins':expected,'existingSourceCatalog':v12['existingSourceCatalog'],
      'externalSources':v12['externalSources'],'inheritedInventory':v12pin,
      'compatibilityInventory':list(labels.values()),'explicitInheritedReferences':sorted(explicit),
      'applications':applications,'applicationIds':[s['id'] for s in SPECS],
      'finalArtifacts':{'manifest':artifactpin,'files':artifactpins,'statistics':artifact['statistics'],
                        'verificationProgramsAndPlan':verification,'separateExistingCompositionReviews':reviewpins,
                        'status':'Exact candidate/companion binding only. Their independent composition review is a separate record, not authored by this inventory.'},
      'newObligationCoverage':{
       'input-parity':['V13-INPUT-PARITY'],'correction-unit':['V13-DETERMINISTIC-CORRECTION','V13-FINITE-SUPPORT'],
       'biquadratic-consumers':['V13-BIQUADRATIC'],'H-half-index':['V13-H-HALF-INDEX','V13-H-TORSION-EXCLUSION','V13-H-SUBTRACTION','V13-H-NO-ROOT','V13-H-LOG-IDENTITIES'],
       'preparation-zero-real-CRT':['V13-REAL-INITIAL','V13-FINITE-SUPPORT','V13-REAL-FINAL-CRT','V13-PREPARATION-ZERO'],
       'normalized-pole-nonzero':['V13-NORMALIZED-SCALAR-POLE'],'anchor-point-first':['V13-ANCHOR-COEFFICIENT','V13-ANCHOR-RESCALING'],
       'ordinary-C-tau':['V13-ORDINARY-GATE']},
      'portability':'All operative paths are repository-relative. The untouched author input files are archived separately. External copyrighted source bytes are identified by the inherited public catalog, not asserted to be redistributed.'}
write(PAYLOAD/PUBLIC/'APPLICATIONS.json',data);stage(PAYLOAD/PUBLIC/'APPLICATIONS.json',PUBLIC+'/APPLICATIONS.json')
contract={'applicationIds':[r['id'] for r in applications],
          'consumerSpans':{r['id']:[[c['start_line'],c['end_line']] for c in r['consumers']] for r in applications},
          'derivationSpans':{r['id']:[r['source']['newDerivation']['start_line'],r['source']['newDerivation']['end_line']] for r in applications},
          'coverage':data['newObligationCoverage'],
          'status':'Author structural coverage contract only; not mathematical acceptance.'}
write(PAYLOAD/PUBLIC/'validation-schema.json',contract);stage(PAYLOAD/PUBLIC/'validation-schema.json',PUBLIC+'/validation-schema.json')
write(HERE/'PATH-MAP.json',mapping)
write(HERE/'BUILD-SUMMARY.json',{'applications':len(applications),'compatibilityLabels':len(labels),'payloadFiles':len(list(PAYLOAD.rglob('*'))),'inventorySha256':sha(PAYLOAD/PUBLIC/'APPLICATIONS.json')})
print((HERE/'BUILD-SUMMARY.json').read_text(encoding='utf-8'))
