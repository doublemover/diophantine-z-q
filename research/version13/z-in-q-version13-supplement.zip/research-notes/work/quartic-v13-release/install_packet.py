"""Install a hash-frozen source packet without overwriting different files."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'quartic-under400-20261107/10-combination/release394'
ROOT = HERE.parent / 'quartic-version6-release/repository'
DEST = ROOT / 'quartics/quartic-394-411'
parser = argparse.ArgumentParser()
parser.add_argument('--manifest-sha256', required=True)
args = parser.parse_args()
raw = (SOURCE / 'PACKAGE-MANIFEST.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == args.manifest_sha256, 'Packet changed'
manifest = json.loads(raw)
for name, entry in manifest.items():
    rel = PurePosixPath(name)
    assert not rel.is_absolute() and '..' not in rel.parts and ':' not in name and '\\' not in name
    data = (SOURCE / name).read_bytes()
    assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256'], name
    target = DEST / name
    assert target.resolve().is_relative_to(DEST.resolve())
    if target.exists():
        assert target.read_bytes() == data, 'Existing file differs: ' + name
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
(DEST / 'PACKAGE-MANIFEST.json').write_bytes(raw)
for src, dest in {
    'quartic-394-symbolic-coefficients.json': 'quartic-394-symbolic-coefficients.json',
    'quartic-394-symbolic-coefficients.txt': 'quartic-394-symbolic-coefficients.txt',
    'quartic-411-ordinary-coefficients.txt': 'quartic-411-fully-expanded.txt',
}.items():
    (ROOT / 'quartics' / dest).write_bytes((DEST / src).read_bytes())
print('Installed', len(manifest), 'frozen packet files and three downloads.')
