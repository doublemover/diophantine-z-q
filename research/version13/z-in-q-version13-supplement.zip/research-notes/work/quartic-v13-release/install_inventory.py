from pathlib import Path, PurePosixPath
import hashlib, json

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'quartic-v13-prep/inventory'
ROOT = HERE.parent / 'quartic-version6-release/repository'
raw = (SOURCE / 'INSTALL-MANIFEST.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'c6fd0cda27b33aae2fab903a7bd55d64ab83ac191b66eb1ca444f63766db1f01'
manifest = json.loads(raw)
for name, item in manifest['files'].items():
    rel = PurePosixPath(name)
    assert not rel.is_absolute() and '..' not in rel.parts and ':' not in name and '\\' not in name
    data = (SOURCE / 'payload' / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == item['sha256'] and len(data) == item['bytes']
    target = ROOT / name
    if target.exists():
        assert target.read_bytes() == data, 'Different existing file: ' + name
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
(ROOT / 'docs/manuscript-revisions/version13/inventory-install-manifest.json').write_bytes(raw)
print('Installed', len(manifest['files']), 'inventory files.')
