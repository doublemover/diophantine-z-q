"""Bind the reviewed v13 addition and data to a minimal manuscript revision."""
from pathlib import Path
import argparse, hashlib, json, re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'quartic-version6-release/repository'
PREP = HERE.parent / 'quartic-v13-prep'
ART = HERE.parent / 'quartic-under400-20261107/10-combination/release394'
parser = argparse.ArgumentParser()
parser.add_argument('--addition-sha256', required=True)
parser.add_argument('--date', required=True)
args = parser.parse_args()

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

addition = (PREP / 'addition.tex').read_bytes()
assert digest(addition) == args.addition_sha256, 'Addition changed'
assert b'\\label{sec:v13}' in addition, 'Final addition is not ready'
metadata = json.loads((ART / 'ARTIFACTS.json').read_bytes())
for name, expected in metadata['files'].items():
    assert digest((ART / name).read_bytes()) == expected, name
assert metadata['statistics']['394']['monomials'] == 6338
assert metadata['statistics']['411']['monomials'] == 6388
assert metadata['statistics']['411']['maximumCoefficientBits'] == 3247
size = (ART / 'quartic-411-ordinary-coefficients.txt').stat().st_size

source = ROOT / 'manuscripts/quartic_v12.tex'
raw = source.read_bytes()
assert digest(raw) == '5ba3f8774732251c178dfabd732d56a41361a73e265666edbd64d49089ebcfd9'
text = raw.decode('utf-8')
old_record = json.loads((ROOT / 'docs/audit-history/current.json').read_bytes())
assert old_record['manuscript']['path'] == 'manuscripts/quartic_v12.tex'
edits = old_record['edits'].copy()
new_edits = []

def edit(name, old, new, kind='mathematical'):
    global text
    assert text.count(old) == 1, (name, text.count(old))
    assert old != new, name
    entry = dict(id=name, old=old, new=new, kind=kind)
    if kind != 'administrative':
        entry['contract_id'] = 'QUARTIC-394-COMPOSITION'
    text = text.replace(old, new, 1)
    edits.append(entry)
    new_edits.append(entry)

edit('v13-title', r'\large Version 12.', r'\large Version 13', 'administrative')
old_date = re.findall(r'\\date\{[^}]+\}', text)
assert len(old_date) == 1
new_date = '\\date{' + args.date + '}'
if old_date[0] != new_date:
    edit('v13-date', old_date[0], new_date, 'administrative')
begin = text.index('We show the minimum degree')
end = text.index('\n\nWell-known consequences', begin)
decimal_bytes = format(size, ',').replace(',', r'\,')
abstract = r'''We show the minimum degree of a Diophantine definition for $\Z$ in $\Q$
is 4 and specify two smaller quartics. The first has $411$ variables,
$6\,388$ nonzero monomials, and coefficients of magnitude below $2^{3247}$;
its complete decimal coefficient table occupies $BYTECOUNT$ bytes.
The second has $394$ variables, $6\,338$ nonzero monomials, and largest
absolute coefficient $16\cdot3^{2^{26}}$. Its table writes coefficients
relative to the fixed integer $C=3^{2^{25}}$.
Both rational zero projections are exactly $\Z$.'''.replace('BYTECOUNT', decimal_bytes)
edit('v13-abstract', text[begin:end], abstract)
start = text.index('Version 12 gives a quartic')
stop = text.index('\n\nVersion 10 clarified', start)
intro = r'''Version 13 gives a quartic in 394 total variables and an ordinary
decimal-coefficient version in 411 total variables. Section~\ref{sec:v13}
proves the reductions from the retained 498-variable construction and
specifies their exact coefficient tables. The preceding constructions
remain as proof baselines. Version 11's index-set and retained-class
identification in the published Kato application is unchanged.'''
edit('v13-introduction', text[start:stop], intro)
edit('v13-proof-addition', r'\begin{thebibliography}{99}',
     addition.decode('utf-8').rstrip() + '\n\n' + r'\begin{thebibliography}{99}')
dest = ROOT / 'docs/manuscript-revisions/version13'
dest.mkdir(parents=True, exist_ok=True)
(ROOT / 'manuscripts/quartic_v13.tex').write_bytes(text.encode('utf-8'))
(dest / 'addition.tex').write_bytes(addition)
for name, data in [('edits.json', edits), ('new-edits.json', new_edits),
                   ('v12-review-record.json', old_record)]:
    (dest / name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8', newline='\n')
receipt = {'source_sha256': digest(raw), 'addition_sha256': digest(addition),
           'manuscript_sha256': digest(text.encode('utf-8')), 'date': args.date,
           'new_edit_ids': [e['id'] for e in new_edits], 'decimal_table_bytes': size,
           'status': 'prepared for full-manuscript review; current acceptance register unchanged'}
(HERE / 'manuscript-preparation.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
